$(document).ready(function () {
  $(".sun").hide(); // Hide the sun icon on page load

  $(".moon").click(function () {
    $(".moon").hide();
    $(".sun").show();
    $(".theme1").css({ backgroundColor: "#182C44" });
    $(".theme2").css({ backgroundColor: "#112339" });
    $("h1,h2,h3,h4,h5,h6,a,#services span,.size,#solution li , .canvas , .cbx1 ,strong").css({ color: "white" });
    $("p").css({ color: "#c2c2c2" });
    $("#gallery h6").css({ color: "black" });
    $("#solution .nav-item button").css({ backgroundColor: "#182C44", color: "white" });
    $("#solution .accordion-item, .accordion-button").css({ backgroundColor: "#112339", color: "white" });
    $("marquee p , .post-slide .post-title a").css({ color: "black" });
  });

  $(".sun").click(function () {
    $(".sun").hide();
    $(".moon").show();
    $(".theme1").css({ backgroundColor: "" });
    $(".theme2").css({ backgroundColor: "" });
    $("h1,h2,h3,h4,h5,h6,a,#services span,.size,#solution li ,.canvas , .cbx1 , strong").css({ color: "" });
    $("p").css({ color: "" });
    $("#solution .nav-item button").css({ backgroundColor: "", color: "" });
    $("#solution .accordion-item, .accordion-button").css({ backgroundColor: "", color: "" });
  });
});


// scrolltop-arrow jquery (arrow at bottom right)
// when to show arrow 
$(document).ready(function () {
  $(".arrow").hide();

  $(window).scroll(function () {
    var s = $(window).scrollTop()   /* scrollTop() function is used to get window vertical scroll value(in pixel)*/
    if (s > 150) {
      $(".arrow").fadeIn(1000)
    }
    else {
      $(".arrow").fadeOut(1000)
    }
  })
});


// scroll effect( user define speed of scrolling)
$(document).ready(function () {

  $(".arrow").click(function (e) {
    e.preventDefault();
    // only applicable for one page website, it prevents page to reload or to naviagte to next page

    var h = this.hash;  /* it gets hash(href) value of every anchor(a) tag */
    $("html , body").animate({
      scrollTop: $(h).offset().top  /* it navigate us to the top of that element */
    }, 2000)  /* time in millisecond, "slow" , "fast"  */
  })
});




// gallery 2 jquery code start

$(document).ready(function () {
  $(".img-wrapper").hover(
    function () {
      $(this).find(".img-overlay").animate({ opacity: 1 }, 600);
    },
    function () {
      $(this).find(".img-overlay").animate({ opacity: 0 }, 600);
    }
  );

  // Lightbox
  var $overlay = $('<div id="overlay"></div>');
  var $image = $("<img>");
  var $prevButton = $('<div id="prevButton"><i class="fa fa-chevron-left"></i></div>');
  var $nextButton = $('<div id="nextButton"><i class="fa fa-chevron-right"></i></div>');
  var $exitButton = $('<div id="exitButton"><i class="fa fa-times"></i></div>');

  // Add overlay
  $overlay.append($image).prepend($prevButton).append($nextButton).append($exitButton);
  $("#gallery").append($overlay);

  // Hide overlay on default
  $overlay.hide();

  // When an image is clicked
  $(".img-overlay").click(function (event) {
    event.preventDefault();
    var imageLocation = $(this).prev().attr("href");
    $image.attr("src", imageLocation);
    $overlay.fadeIn("slow");
  });

  // When the overlay is clicked
  $overlay.click(function () {
    $(this).fadeOut("slow");
  });

  // When next button is clicked
  $nextButton.click(function (event) {
    $("#overlay img").hide();
    var $currentImgSrc = $("#overlay img").attr("src");
    var $currentImg = $('#image-gallery img[src="' + $currentImgSrc + '"]');
    var $nextImg = $($currentImg.closest(".image").next().find("img"));
    var $images = $("#image-gallery img");
    if ($nextImg.length > 0) {
      $("#overlay img").attr("src", $nextImg.attr("src")).fadeIn(800);
    } else {
      $("#overlay img").attr("src", $($images[0]).attr("src")).fadeIn(800);
    }
    event.stopPropagation();
  });

  // When previous button is clicked
  $prevButton.click(function (event) {
    $("#overlay img").hide();
    var $currentImgSrc = $("#overlay img").attr("src");
    var $currentImg = $('#image-gallery img[src="' + $currentImgSrc + '"]');
    var $nextImg = $($currentImg.closest(".image").prev().find("img"));
    $("#overlay img").attr("src", $nextImg.attr("src")).fadeIn(800);
    event.stopPropagation();
  });

  // When the exit button is clicked
  $exitButton.click(function () {
    $("#overlay").fadeOut("slow");
  });
});

// gallery 2 jquery code finish




// utube 2 jquery code start

$(document).ready(function () {
$(function(){
	$('.mhn-slide').owlCarousel({
		nav:true,
		//loop:true,
		slideBy:'page',
		rewind:false,
		responsive:{
			0:{items:1},
			480:{items:2},
			600:{items:3},
			1000:{items:4}
		},
		smartSpeed:70,
		onInitialized:function(e){
			$(e.target).find('img').each(function(){
				if(this.complete){
					$(this).closest('.mhn-inner').find('.loader-circle').hide();
					$(this).closest('.mhn-inner').find('.mhn-img').css('background-image','url('+$(e.target).attr('src')+')');
				}else{
					$(this).bind('load',function(e){
						$(e.target).closest('.mhn-inner').find('.loader-circle').hide();
						$(e.target).closest('.mhn-inner').find('.mhn-img').css('background-image','url('+$(e.target).attr('src')+')');
					});
				}
			});
		},
		navText:['<svg viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></svg>','<svg viewBox="0 0 24 24"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></svg>']
	});
});
});

// utube 2 jquery code ends


// moving alphabets jquery code start

$(document).ready(function () {
  $('.counter').countUp();
});

// moving alphabets jquery code ends



// owl 1 jquery code start
$(document).ready(function() {
  $("#news-slider").owlCarousel({
      items : 3,
      itemsDesktop:[1199,3],
      itemsDesktopSmall:[980,2],
      itemsMobile : [600,1],
      navigation:true,
      navigationText:["",""],
      pagination:true,
      autoPlay:true
  });
});
// owl 1 jquery code end



// Zoomple jquery code starts

$(document).ready(function () {
  $(".small").mouseover(function(){
    $(".box").empty()
    $(this).clone().addClass("big").appendTo(".box")       // clone is for copy image
})
});

$(document).ready(function() { 
  $('.zoomple').zoomple({ 
      blankURL : 'assets/images/blank.gif',  /* when no image in img show blank.gif */
      bgColor : 'white',   /* u can change color while magnify*/
      loaderURL : 'assets/images/loader.gif', /* when no image in href show loader.gif */
      /* offset : {x:-150,y:-150},  position of cursor(mouse arrow) */
      offset : {x:358,y:100}, /* position of cursor(mouse arrow) */
      zoomWidth : 230,  
      zoomHeight : 230,
      roundedCorners : true,  /* on true round shape zoomer and on false square shape zoomer*/
      attachWindowToMouse:false,  /* on false it will stay at one place and on true it will move with cursor*/
      windowPosition: {x:'right',y:'bottom'}/* when we apply this, change offset to 150,150 to 0,0(done upper)*/
  });
})

// Zoomple jquery code ends
