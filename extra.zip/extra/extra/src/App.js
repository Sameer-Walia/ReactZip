import { ToastContainer } from 'react-toastify';
import './App.css';
import 'aos/dist/aos.css';
import Siteroutes from './components/Siteroutes';
import Header from './components/Header';
import Header1 from './components/Header1';

function App()
{
  return (
    <>
      {/* <Header/> */}
      <Header1 />
      <Siteroutes />
      <ToastContainer theme="colored" />
    </>
  );
}

export default App;
