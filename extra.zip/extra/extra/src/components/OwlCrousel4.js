import React, { useEffect } from 'react'

function OwlCrousel4() {

    return (
        <div id='owl4' className='pd mt-5 theme2'>
            <div class="container">
                <div class="mhn-slide owl-carousel">
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/blog1.jpg" />
                            <div class="mhn-text">
                                <h4>Paper</h4>
                                <p>Paper is a thin material produced by pressing together moist fibres of cellulose pulp derived from wood, rags or grasses, and drying them into flexible sheets.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/blog2.jpg" />
                            <div class="mhn-text">
                                <h4>Fire</h4>
                                <p>Fire is the rapid oxidation of a material in the exothermic chemical process of combustion, releasing heat, light, and various reaction products.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/blog3.jpg" />
                            <div class="mhn-text">
                                <h4>Nature</h4>
                                <p>Nature, in the broadest sense, is the natural, physical, or material world or universe. "Nature" can refer to the phenomena of the physical world, and also to life in general.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/product1.jpg" alt="" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                            <div class="mhn-text">
                                <h4>Video</h4>
                                <p>Video is an electronic medium for the recording, copying, playback, broadcasting, and display of moving visual media.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/product2.jpg" alt="" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                            <div class="mhn-text">
                                <h4>Hiking</h4>
                                <p>Hiking is the preferred term, in Canada and the United States, for a long, vigorous walk, usually on trails (footpaths), in the countryside, while the word walking is used for shorter, particularly urban walks.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/product3.jpg" alt="" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                            <div class="mhn-text">
                                <h4>Future</h4>
                                <p>The future is the time after the present. Future or The Future may also refer to: Futures contract, a standardized financial contract; Future (programming) · Future tense, in grammar. Contents.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/service1.jpg" alt="" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                            <div class="mhn-text">
                                <h4>Music</h4>
                                <p>Music is an art form and cultural activity whose medium is sound organized in time. The common elements of music are pitch rhythm dynamics (loudness and softness), and the sonic qualities of timbre and texture (which are sometimes termed the "color" of a musical sound).</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/service2.jpg" alt="" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                            <div class="mhn-text">
                                <h4>Money</h4>
                                <p>Money is any item or verifiable record that is generally accepted as payment for goods and services and repayment of debts in a particular country or socio-economic context.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/service3.jpg" alt="" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                            <div class="mhn-text">
                                <h4>Happiness</h4>
                                <p>In psychology, happiness is a mental or emotional state of well-being which can be defined by, among others, positive or pleasant emotions ranging from contentment to intense joy.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/job1.jpg" alt="" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                            <div class="mhn-text">
                                <h4>Nepal</h4>
                                <p>Nepal is a landlocked central Himalayan country in South Asia. Nepal is divided into 7 states and 77 districts and 744 local units including 4 metropolises, 13 sub-metropolises, 246 municipal councils and 481 villages.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/job2.jpg" alt="" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                            <div class="mhn-text">
                                <h4>Love</h4>
                                <p>Love encompasses a variety of different emotional and mental states, typically strongly and positively experienced, ranging from the deepest interpersonal affection to the simplest pleasure.</p>
                            </div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/job3.jpg" alt="" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                            <div class="mhn-text">
                                <h4>Sports</h4>
                                <p>A sport is commonly defined as an athletic activity or skill and involves a degree of competition, such as tennis or basketball. Some games and many kinds of racing are called sports.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default OwlCrousel4

