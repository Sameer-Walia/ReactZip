import React from 'react'
import Footer from './Footer';

function Gallery3() {
    return (
        <div>
            <section id="gallery" className='theme1'>
                <div class="container">
                    <p class="text-center hd mt-5 ">Various Photos Of Nauvaraha</p>
                    <h1 class="text-center pg mb-3">PHOTO GALLERY 3</h1>
                    <div class="row">
                        <a href="assets/images/blog3.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                            <img src="assets/images/blog3.jpg" class="img-fluid rounded" />
                        </a>
                        <a href="assets/images/blog2.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                            <img src="assets/images/blog2.jpg" class="img-fluid rounded" />
                        </a>
                        <a href="assets/images/blog1.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                            <img src="assets/images/blog1.jpg" class="img-fluid rounded" />
                        </a>
                    </div>
                    <div class="row py-5">
                        <a href="assets/images/service1.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                            <img src="assets/images/service1.jpg" class="img-fluid rounded" />
                        </a>
                        <a href="assets/images/service2.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                            <img src="assets/images/service2.jpg" class="img-fluid rounded" />
                        </a>
                        <a href="assets/images/service3.jpg" data-toggle="lightbox" data-gallery="gallery" class="col-md-4">
                            <img src="assets/images/service3.jpg" class="img-fluid rounded" />
                        </a>
                    </div>
                </div>
            </section>
            <Footer/>
        </div>
    )
}

export default Gallery3
