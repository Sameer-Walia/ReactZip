import React, { useEffect } from 'react'
import { Link } from 'react-router-dom';
import Footer from './Footer';
import AOS from 'aos';
import 'aos/dist/aos.css';


function Home() {

    useEffect(() => {
        const carousel = new window.bootstrap.Carousel(document.getElementById('carouselExampleCaptions'), {
            interval: 2500, // 3 seconds
            ride: 'carousel'
        });
    }, []);

    useEffect(() => {
        AOS.init({ duration: 1000, once: false }); // 'once: false' ensures animations trigger every scroll
    }, []);

    return (

        <div>

            <marquee className="marquee" behavior="scroll" scrollamount="20" >
                <p>
                    📊 Welcome to the Feedback Portal for Educational Institutions! &nbsp; 💡 Empowering Teachers Through Actionable Feedback! &nbsp; 📋 Analyze Teacher Performance with In-Depth Feedback Reports! &nbsp; ⏱️ Real-Time Feedback Analysis for Continuous Improvement!
                </p>
            </marquee>

            <div id="carouselExampleCaptions" class="carousel slide sam"  >
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>

                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="assets/images/job5.jpg" class="d-block w-100" alt="..." />
                        <div class="carousel-caption">
                            <h3>We are Creative</h3>
                            <h1>World IT Service company </h1>
                            <p>Get the most of reduction in your team’s operating creates amazing UI/UX experiences. </p>
                            <Link to="/sam" className=' btn btn1'>Learn More</Link>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="assets/images/job6.jpg" class="d-block w-100" alt="..." />
                        <div class="carousel-caption">
                            <h3>We are Creative</h3>
                            <h1>World IT Service company </h1>
                            <p>Get the most of reduction in your team’s operating creates amazing UI/UX experiences. </p>
                            <Link to="/sam" className='btn btn1'>Learn More</Link>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="assets/images/job7.jpg" class="d-block w-100" alt="..." />
                        <div class="carousel-caption">
                            <h3>We are Creative</h3>
                            <h1>World IT Service company </h1>
                            <p>Get the most of reduction in your team’s operating creates amazing UI/UX experiences. </p>
                            <Link to="/sam" className='btn btn1'>Learn More</Link>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="assets/images/job8.jpg" class="d-block w-100" alt="..." />
                        <div class="carousel-caption">
                            <h3>We are Creative</h3>
                            <h1>World IT Service company </h1>
                            <p>Get the most of reduction in your team’s operating creates amazing UI/UX experiences. </p>
                            <Link to="/sam" className='btn btn1'>Learn More</Link>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev sss" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next sss" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>

            <div id='about' className='pd theme1'>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-12 mar" data-aos="fade-up-right" data-aos-delay="100">
                            <h1 class="pt-4 hd">Best IT Solution Service From Experienced Engineer.</h1>
                            <p class="pg pt-4 mb-3">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, sed ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet elit. Non quae, fugiat nihil ad.</p>

                            <p class="pg pb-4" >Pellen tesque libero ut justo, ultrices in ligula. Semper at. Lorem init ipsum dolor sit amet elit. Dolor ipsum non velit, culpa! Pellen tesque libero ut justo, ultrices in ligula amet dolor sit init dolor sit, amet elit. Dolor ipsum non velit, culpa! elit ut et.</p>

                            <Link to="" class="btn btn1 me-5 mt-md-4">Explore features</Link>
                            <Link to="" class="btn btn2 rounded mt-md-4">View All</Link>
                        </div>
                        <div class="col-lg-6 col-12 mt-lg-0 mt-5"  data-aos="fade-down-left" data-aos-delay="100">
                            <img src="assets/images/about1.jpg" className='img-fluid rounded'></img>
                        </div>
                    </div>
                </div>
            </div>

            <div id="services" className='bg pd theme2'>
                <div class="container">
                    <h1 class="text-center hd " data-aos="fade-up">Some of Our Digital IT Services</h1>

                    <div class="row pt-5 ">
                        <div class="col-lg-4 col-md-6 col-sm-12 px-4">
                            <div class="card"  data-aos="zoom-out-left" data-aos-delay="100">
                                <img src="assets/images/service1.jpg" class="card-img-top" alt="..." />
                                <div class="card-body theme1">
                                    <div class="row">
                                        <div class="col-2 pt-3">
                                            <span className='fa fa-desktop'></span>
                                        </div>
                                        <div class="col-10">
                                            <Link to="">Work Expertise & Leadership</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 mt-md-0 mt-5 px-4">
                            <div class="card"  data-aos="zoom-out-down" data-aos-delay="200">
                                <img src="assets/images/service2.jpg" class="card-img-top" alt="..." />
                                <div class="card-body theme1">
                                    <div class="row">
                                        <div class="col-2 pt-3">
                                            <span className='fa fa-cogs'></span>
                                        </div>
                                        <div class="col-10">
                                            <Link to="">Digital Product Development</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12  mt-lg-0 mt-5 mx-auto px-4">
                            <div class="card"  data-aos="zoom-out-right" data-aos-delay="300">
                                <img src="assets/images/service3.jpg" class="card-img-top" alt="..." />
                                <div class="card-body theme1">
                                    <div class="row">
                                        <div class="col-2 pt-3">
                                            <span className='fa fa-line-chart'></span>
                                        </div>
                                        <div class="col-10">
                                            <Link to="">Business Software Development</Link>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="solution" className='pd theme1'>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-12" data-aos="flip-up" data-aos-delay="100">
                            <h1 class="hd">Need a Better Work? We are here to IT Solution with 30 years of experience</h1>
                            <ul class="nav nav-tabs mt-4 mb-4 nav-fill" id="myTab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">What we do</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Our Mission</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact-tab-pane" type="button" role="tab" aria-controls="contact-tab-pane" aria-selected="false">Social impact</button>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                                    <h3>To believe that the smart looking website is the first impression all over.</h3>
                                    <p class="pg">This Our History to a tendency to believe that the smart looking website is the first impression. Lorem dolor sit amet, elit!</p>
                                    <ul class="list-unstyled">
                                        <li><span class="fa fa-check"></span>Leading private equity firms</li>
                                    </ul>
                                </div>
                                <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                                    <h3>This Our History to a tendency to believe that the smart looking website is the first impression.</h3>
                                    <p class="pg">Lorem ipsum dolor sit amet, elit. Id ab commodi impedit magnam sint voluptates. Minima velit expedita maiores, sit at in!</p>
                                    <ul class="list-unstyled">
                                        <li><span class="fa fa-check"></span>Helping Nonprofit organizations</li>
                                        <li><span class="fa fa-check"></span>   Leading private equity firms</li>
                                    </ul>
                                </div>
                                <div class="tab-pane fade" id="contact-tab-pane" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">
                                    <h3>This Our History to a tendency to believe thes that smart looking website is the first impression.</h3>
                                    <p class="pg"> Lorem ipsum dolor sit amet, elit. Id ab commodi impedit magnam sint voluptates. Minima velit expedita maiores, sit at in!!</p>
                                    <ul class="list-unstyled">
                                        <li><span class="fa fa-check"></span> Always Fast and friendly support</li>
                                        <li><span class="fa fa-check"></span> Experienced Professional Team</li>
                                    </ul>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-6 col-12 ps-4 mt-lg-0 mt-4" data-aos="flip-down" data-aos-delay="100">
                            <div class="accordion" id="accordionExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            How much does a static website cost?
                                            <span class="plus"><i class="fa-solid fa-circle-plus"></i></span>
                                            <span class="minus"><i class="fa-solid fa-circle-minus"></i></span>
                                        </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                        <div class="accordion-body ps-0">
                                            <p className='pg '>
                                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Velit eos vero quis quas eius distinctio nostrum voluptas numquam? Dolores dolor magni obcaecati iusto tempora esse rem at repellat vero beatae!
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            How to choose a best web template?
                                            <span class="plus"><i class="fa-solid fa-circle-plus"></i></span>
                                            <span class="minus"><i class="fa-solid fa-circle-minus"></i></span>
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div class="accordion-body ps-0">
                                            <p className='pg'>
                                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Velit eos vero quis quas eius distinctio nostrum voluptas numquam? Dolores dolor magni obcaecati iusto tempora esse rem at repellat vero beatae!
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            How to download a template?
                                            <span class="plus"><i class="fa-solid fa-circle-plus"></i></span>
                                            <span class="minus"><i class="fa-solid fa-circle-minus"></i></span>
                                        </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div class="accordion-body ps-0">
                                            <p className='pg'>
                                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Velit eos vero quis quas eius distinctio nostrum voluptas numquam? Dolores dolor magni obcaecati iusto tempora esse rem at repellat vero beatae!
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            Why should i choose a free website?
                                            <span class="plus"><i class="fa-solid fa-circle-plus"></i></span>
                                            <span class="minus"><i class="fa-solid fa-circle-minus"></i></span>
                                        </button>
                                    </h2>
                                    <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div class="accordion-body ps-0">
                                            <p className='pg'>
                                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Velit eos vero quis quas eius distinctio nostrum voluptas numquam? Dolores dolor magni obcaecati iusto tempora esse rem at repellat vero beatae!
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            Why should i choose a free website?
                                            <span class="plus"><i class="fa-solid fa-circle-plus"></i></span>
                                            <span class="minus"><i class="fa-solid fa-circle-minus"></i></span>
                                        </button>
                                    </h2>
                                    <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                        <div class="accordion-body ps-0">
                                            <p className='pg'>
                                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Velit eos vero quis quas eius distinctio nostrum voluptas numquam? Dolores dolor magni obcaecati iusto tempora esse rem at repellat vero beatae!
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="process" className='pd bg theme2'>
                <div class="container">
                    <h1 className='hd text-center col-lg-5 col-md-9 mx-auto' data-aos="fade-down">Come for Visit to See our Work Process</h1>
                    <div class="row mt-5">
                        <div class="col-lg-3 col-md-6 col-12" data-aos="slide-left" data-aos-delay="100">
                            <div className='effect'>
                                <img src="assets/images/process4.jpg" alt="" className='rounded img-fluid' />
                                <div class="eff rounded">
                                    <h4 className=''>Dedicated IT Solution</h4>
                                    <p class="pg">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Similique quas officiis!</p>
                                </div>
                                <span class="fa fa-plus"></span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-md-0 mt-5" data-aos="slide-up" data-aos-delay="100">
                            <div className='effect'>
                                <img src="assets/images/process3.jpg" alt="" className='rounded img-fluid' />
                                <div class="eff rounded">
                                    <h4 className=''>Dedicated IT Solution</h4>
                                    <p class="pg">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Similique quas officiis!</p>
                                </div>
                                <span class="fa fa-plus"></span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-lg-0 mt-5" data-aos="slide-up" data-aos-delay="100">
                            <div className='effect'>
                                <img src="assets/images/process1.jpg" alt="" className='rounded img-fluid' />
                                <div class="eff rounded">
                                    <h4 className=''>Dedicated IT Solution</h4>
                                    <p class="pg">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Similique quas officiis!</p>
                                </div>
                                <span class="fa fa-plus"></span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12  mt-lg-0 mt-5" data-aos="slide-right" data-aos-delay="100">
                            <div className='effect'>
                                <img src="assets/images/process2.jpg" alt="" className='rounded img-fluid' />
                                <div class="eff rounded">
                                    <h4 className=''>Dedicated IT Solution</h4>
                                    <p class="pg">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Similique quas officiis!</p>
                                </div>
                                <span class="fa fa-plus"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="join" class="pd theme1">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-12 ps-5" data-aos="zoom-in" data-aos-delay="100">
                            <h1 className='hd'>Start improving your Business today! Join Us</h1>
                            <p className='pg'>
                                Lorem ipsum dolor sit amet elit. Velit beatae rem ullam dolore nisi esse quasi. Integer sit amet. Lorem ipsum dolor sit amet elit.
                            </p>
                        </div>
                        <div class="col-lg-6 col-12 text-lg-end mt-4 pe-5 ps-5" data-aos="zoom-in" data-aos-delay="300">
                            <Link to="/sam" className=' btn btn3 me-3'>Learn More</Link>
                            <Link to="/sam" className=' btn btn1'>Contact Us</Link>
                        </div>
                    </div>
                </div>
            </div>

            <div id="products" className='pd bg theme2'>
                <div class="container">
                    <h1 className='hd text-center col-lg-5 col-9 mx-auto' data-aos="fade-down">To design and deliver the innovative products.</h1>
                    <div class="row mt-5" >
                        <div class="col-lg-4 col-md-6 col-12" data-aos="flip-down" data-aos-delay="100"> 
                            <div class="pro rounded pr1 theme1">
                                <span class="fa-regular fa-sun" aria-hidden="true"></span>
                                <h3>Augmented Reality</h3>
                                <p>Lorem ipsum dolor sit amet elit et. Debitis nam, minima iste ipsum.</p>
                                <Link>Read More</Link>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mt-md-0 mt-5" data-aos="flip-down" data-aos-delay="100">
                            <div class="pro rounded pr2 theme1">
                                <span class="fa fa-wrench icon-fea" aria-hidden="true"></span>
                                <h3>Deep Expertise</h3>
                                <p>Lorem ipsum dolor sit amet elit et. Debitis nam, minima iste ipsum.</p>
                                <Link>Read More</Link>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mt-lg-0 mt-5 mx-auto" data-aos="flip-down" data-aos-delay="100">
                            <div class="pro rounded pr3 theme1">
                                <span class="fa fa-flask" aria-hidden="true"></span>
                                <h3>Software development</h3>
                                <p>Lorem ipsum dolor sit amet elit et. Debitis nam, minima iste ipsum.</p>
                                <Link>Read More</Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="ideas" class="pd theme1">
                <div class="container">
                    <h1 className='hd text-center ' data-aos="flip-down" data-aos-delay="100">Our Great Idea For IT News.</h1>
                    <div class="row mt-5">
                        <div class="col-lg-4 col-md-6 col-12" data-aos="fade-down-right" data-aos-delay="100">
                            <div class="card">
                                <div className='exact rounded'>
                                    <img src="assets/images/blog1.jpg" class="card-img-top" alt="..." />
                                    <div class="exa rounded">
                                        <span class="fa fa-plus rounded"></span>
                                    </div>
                                </div>
                                <div class="card-body theme2">
                                    <div class="row pt-3">
                                        <div class="col-5 hd mt-1"><h6 >Jan 15, 2021.</h6></div>
                                        <div class="col-7 cc"><h6>Business,Case Study</h6></div>
                                    </div><br />
                                    <Link className='anchor'>Designers Checklist for Every UX Project they Do.</Link><br /><br />
                                    <Link className='anchor'>Read more <span class="fa fa-arrow-right"></span></Link>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mt-md-0 mt-5" data-aos="zoom-in" data-aos-delay="100">
                            <div class="card">
                                <div className='exact rounded'>
                                    <img src="assets/images/blog2.jpg" class="card-img-top" alt="..." />
                                    <div class="exa rounded">
                                        <span class="fa fa-plus rounded"></span>
                                    </div>
                                </div>
                                <div class="card-body theme2">
                                    <div class="row pt-3">
                                        <div class="col-5 hd mt-1"><h6 >Jan 15, 2021.</h6></div>
                                        <div class="col-7 cc"><h6>Business,Case Study</h6></div>
                                    </div><br />
                                    <Link className='anchor'>Designers Checklist for Every UX Project they Do.</Link><br /><br />
                                    <Link className='anchor'>Read more <span class="fa fa-arrow-right"></span></Link>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mt-lg-0 mt-5 mx-auto" data-aos="fade-down-left" data-aos-delay="100">
                            <div class="card">
                                <div className='exact rounded'>
                                    <img src="assets/images/blog3.jpg" class="card-img-top" alt="..." />
                                    <div class="exa rounded">
                                        <span class="fa fa-plus rounded"></span>
                                    </div>
                                </div>
                                <div class="card-body theme2">
                                    <div class="row pt-3">
                                        <div class="col-5 hd mt-1"><h6 >Jan 15, 2021.</h6></div>
                                        <div class="col-7 cc"><h6>Business,Case Study</h6></div>
                                    </div><br />
                                    <Link className='anchor'>Designers Checklist for Every UX Project they Do.</Link><br /><br />
                                    <Link className='anchor'>Read more <span class="fa fa-arrow-right"></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <Footer/>

            <Link to="#header" className="arrow"><i class="fa-solid fa-arrow-up-from-bracket"></i></Link>

        </div>
    )
}

export default Home
