import React from 'react'
import Footer from './Footer';

function Utube()
{
    return (
        <>
            <div id='utube' className='pd theme1 mt-5'>

                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="video-wrapper">
                                <iframe
                                    src="https://www.youtube.com/embed/SIm3nKfJnFE?si=Or3_HP0wz8sN8kkD"
                                    title="YouTube video player"
                                    allow="autoplay; encrypted-media; picture-in-picture"
                                    allowfullscreen
                                    referrerpolicy="strict-origin-when-cross-origin"
                                    loading="lazy">
                                </iframe>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mt-md-0 mt-5">
                            <div class="video-wrapper">
                                <iframe
                                    src="https://www.youtube.com/embed/um2Q9aUecy0?si=9eA-QeO-2-fba1TJ"
                                    title="YouTube video player"
                                    allow="autoplay; encrypted-media; picture-in-picture"
                                    allowfullscreen
                                    referrerpolicy="strict-origin-when-cross-origin"
                                    loading="lazy">
                                </iframe>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mt-lg-0 mt-5 mx-auto">
                            <div class="video-wrapper">
                                <iframe
                                    src="https://www.youtube.com/embed/XTp5jaRU3Ws?si=DoTSTGZ8D4esy3T8"
                                    title="YouTube video player"
                                    allow="autoplay; encrypted-media; picture-in-picture"
                                    allowfullscreen
                                    referrerpolicy="strict-origin-when-cross-origin"
                                    loading="lazy">
                                </iframe>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="container pd mt-5">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-12 text-center">
                            <iframe src="https://www.youtube.com/embed/SIm3nKfJnFE?si=Or3_HP0wz8sN8kkD" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen class="rounded"></iframe>

                        </div>
                        <div class="col-lg-4 col-md-6 col-12 text-center">
                            <iframe src="https://www.youtube.com/embed/um2Q9aUecy0?si=9eA-QeO-2-fba1TJ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen class="rounded" ></iframe>

                        </div>
                        <div class="col-lg-4 col-md-6 col-12 text-center">
                            <iframe src="https://www.youtube.com/embed/9G69n11o3z8?si=1c-5Nd_MGOdtFn-b" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen class="rounded"></iframe>

                            {/* <iframe src="https://www.youtube.com/embed/XTp5jaRU3Ws?si=DoTSTGZ8D4esy3T8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe> */}

                        </div>
                    </div>
                </div>

                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3407.927515442429!2d75.55728767441632!3d31.33337485635914!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a5a93bfffffff%3A0xc38cdf8f9db5c24a!2sM.G.N.%20Public%20School!5e0!3m2!1sen!2sin!4v1714766533665!5m2!1sen!2sin" width="100%" height="550" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

            </div >
            <Footer />
        </>


    )
}

export default Utube
