import React, { useState } from 'react'

function Tasks() {

    const [filtersVisible, setFiltersVisible] = useState(false);
    const [category, setCategory] = useState("");
    const [minBudget, setMinBudget] = useState("");
    const [maxBudget, setMaxBudget] = useState("");
    const [location, setLocation] = useState("");


    return (
        <div id='tasks'>
            <div className='container'>
                <h1 className="task-title">Browse Tasks</h1>

                <div className="task-search-bar">
                    <input type="text" placeholder="Search tasks..." className="task-input"/>
                </div>

                <button
                    onClick={() => setFiltersVisible(!filtersVisible)}
                    className="task-button mb-3"
                >
                    {filtersVisible ? "Hide Filters" :"Show Filters" }
                </button>

                {
                    filtersVisible  ? 
                    <div className="task-filters">
                        <select
                            value={category}
                            onChange={(e) => setCategory(e.target.value)}
                            className="task-filter-select"
                        >
                            <option value="">All Categories</option>
                            <option value="Web Development">Web Development</option>
                            <option value="Graphic Design">Graphic Design</option>
                            <option value="Marketing">Marketing</option>
                        </select>

                        <div className="task-budget-group">
                            <input
                                type="number"
                                placeholder="Min $"
                                value={minBudget}
                                onChange={(e) => setMinBudget(e.target.value)}
                                className="task-budget-input"
                            />
                            <input
                                type="number"
                                placeholder="Max $"
                                value={maxBudget}
                                onChange={(e) => setMaxBudget(e.target.value)}
                                className="task-budget-input"
                            />
                        </div>

                        <input
                            type="text"
                            placeholder="Location"
                            value={location}
                            onChange={(e) => setLocation(e.target.value)}
                            className="task-filter-input"
                        />

                        <button  className="task-button">
                            Apply Filters
                        </button>
                    </div>
                :null
                }
            </div>
        </div>
    )
}

export default Tasks
