import React from 'react'
import { Link } from 'react-router-dom'

function Header() {
  return (
    <div id='header' className='fixed-top'>
      <nav className="navbar navbar-expand-lg fixed-top theme1">
        <div class="container">
          <a class="navbar-brand" href="#"><h3><i className="fa-solid fa-graduation-cap sr1"></i>&nbsp;HIREIQ</h3></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvas2" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 ">
              <li class="nav-item">
                <Link to="/" class="nav-link active">Home</Link>
              </li>
              <li class="nav-item">
                <Link to="home2" class="nav-link">Home2</Link>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Dropdown
                </a>
                <ul class="dropdown-menu">
                  <li><Link to="utube" class="dropdown-item">Youtube 1</Link></li>
                  <li><Link to="utube2" class="dropdown-item">Youtube 2</Link></li>
                  <li><hr class="dropdown-divider" /></li>
                  <li><Link to="owl1" class="dropdown-item">Owl-Crousel 1</Link></li>
                  <li><Link to="owl2" class="dropdown-item">Owl-Crousel 2</Link></li>
                  <li><Link to="owl3" class="dropdown-item">Owl-Crousel 3</Link></li>
                  <li><Link to="owl4" class="dropdown-item">Owl-Crousel 4</Link></li>
                  <li><Link to="owl5" class="dropdown-item">Owl-Crousel 5</Link></li>

                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Gallery
                </a>
                <ul class="dropdown-menu">
                  <li><Link to="gallery1" class="dropdown-item">Gallery1</Link></li>
                  <li><Link to="gallery2" class="dropdown-item">Gallery2</Link></li>
                  <li><hr class="dropdown-divider" /></li>
                  <li><Link to="gallery3" class="dropdown-item">Gallery3</Link></li>
                  <li><Link to="vedio" class="dropdown-item">Vedio</Link></li>
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Form
                </a>
                <ul class="dropdown-menu">
                  <li><Link to="form1" class="dropdown-item">Form1</Link></li>
                  <li><Link to="login" class="dropdown-item">Form2</Link></li>
                  <li><Link to="zoomple" class="dropdown-item">Zoomple</Link></li>
                  <li><Link to="div" class="dropdown-item">Div</Link></li>
                </ul>
              </li>
            </ul>

            <i class="fa-solid fa-magnifying-glass sr2"></i>
            <Link to="/" className='btn btn1 mx-2'>Purchase</Link>
          </div>

          <span class="moon size me-3"><i class="fa-regular fa-moon"></i></span>
          <span class="sun size me-3"><i class="fa-regular fa-sun"></i></span>

          <span class="info pointer canvas" data-bs-toggle="offcanvas" data-bs-target="#offcanvas1">
            <i class="fa-solid fa-circle-info"></i>
          </span>



        </div>

      </nav>

      <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvas1" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header">
          <a class="navbar-brand mx-auto" href="#"><h3><i className="fa-solid fa-graduation-cap sr1"></i>&nbsp;HIREIQ</h3></a>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body" id='footercanvas'>
          <div>
            Some text as placeholder. In real life you can have the elements you have chosen. Like, text, images, lists, etc.
          </div>
          <h3 class="pb-3 mt-5" >Contact Info</h3>
          <ul class="list-unstyled">
            <li>Address : <a href="">Excellence Solutions, 343 marketing, #2214 cravel street, NY - 62617.</a></li>
            <li>Phone : <a href="">+1(21) 234 4567</a></li>
            <li>Email : <a href="">info@example.com</a></li>
            <li>Support : <a href="">info@support.com</a></li>
          </ul>
          <h3 class="pb-3 mt-5">Navigation</h3>
          <ul class="list-unstyled">
            <li><a href="">About Us</a></li>
            <li><a href="">Blog posts</a></li>
            <li><a href="">Services</a></li>
            <li><a href="">Contact us</a></li>
            <li><a href="">Components</a></li>
          </ul>
          <h3 class="pb-3 mt-5">Follow Us</h3>
          <a href=""><i class="fa-brands fa-twitter"></i></a>
          <a href=""><i class="fa-brands fa-facebook"></i></a>
          <a href=""><i class="fa-brands fa-instagram"></i></a>
          <a href=""><i class="fa-brands fa-linkedin"></i></a>
        </div>
      </div>

      <div class="offcanvas offcanvas-start text-bg-dark" tabindex="-1" id="offcanvas2" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header">
          <a class="navbar-brand mx-auto" href="#"><h3><i className="fa-solid fa-graduation-cap sr1"></i>&nbsp;HIREIQ</h3></a>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <div>
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <Link to="/" class="nav-link active">Home</Link>
              </li>
              <li class="nav-item">
                <Link to="home2" class="nav-link">Home2</Link>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Dropdown
                </a>
                <ul class="dropdown-menu">
                  <li><Link to="utube" class="dropdown-item">Youtube 1</Link></li>
                  <li><Link to="utube2" class="dropdown-item">Youtube 2</Link></li>
                  <li><hr class="dropdown-divider" /></li>
                  <li><Link to="owl1" class="dropdown-item">Owl-Crousel 1</Link></li>
                  <li><Link to="owl2" class="dropdown-item">Owl-Crousel 2</Link></li>
                  <li><Link to="owl3" class="dropdown-item">Owl-Crousel 3</Link></li>
                  <li><Link to="owl4" class="dropdown-item">Owl-Crousel 4</Link></li>
                  <li><Link to="owl5" class="dropdown-item">Owl-Crousel 5</Link></li>

                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Gallery
                </a>
                <ul class="dropdown-menu">
                  <li><Link to="gallery1" class="dropdown-item">Gallery1</Link></li>
                  <li><Link to="gallery2" class="dropdown-item">Gallery2</Link></li>
                  <li><hr class="dropdown-divider" /></li>
                  <li><Link to="gallery3" class="dropdown-item">Gallery3</Link></li>
                  <li><Link to="vedio" class="dropdown-item">Vedio</Link></li>
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Form
                </a>
                <ul class="dropdown-menu">
                  <li><Link to="form1" class="dropdown-item">Form1</Link></li>
                  <li><Link to="login" class="dropdown-item">Form2</Link></li>
                  <li><Link to="zoomple" class="dropdown-item">Zoomple</Link></li>
                  <li><Link to="div" class="dropdown-item">Div</Link></li>
                </ul>
              </li>
            </ul>
          </div>
          <div id='footercanvas'>
            <h3 class="pb-3 mt-5" >Contact Info</h3>
            <ul class="list-unstyled">
              <li>Address : <a href="">Excellence Solutions, 343 marketing, #2214 cravel street, NY - 62617.</a></li>
              <li>Phone : <a href="">+1(21) 234 4567</a></li>
              <li>Email : <a href="">info@example.com</a></li>
              <li>Support : <a href="">info@support.com</a></li>
            </ul>
          </div>
        </div>
      </div>


    </div>
  )
}

export default Header
