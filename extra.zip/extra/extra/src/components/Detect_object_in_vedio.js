import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Detect_object_in_vedio() {
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [previewURL, setPreviewURL] = useState(null);
  const [outputVideoURL, setOutputVideoURL] = useState(null);
  const [loading, setLoading] = useState(false);

  function handleVideoChange(e) {
    const file = e.target.files[0];
    setSelectedVideo(file);
    setPreviewURL(URL.createObjectURL(file));
    setOutputVideoURL(null); // Clear previous output
  }

  useEffect(() => {
    return () => {
      if (outputVideoURL) URL.revokeObjectURL(outputVideoURL);
      if (previewURL) URL.revokeObjectURL(previewURL);
    };
  }, [outputVideoURL, previewURL]);

  const handlePredict = async () => {
    if (!selectedVideo)
    {
      alert("Please upload a video first.");
      return;
    }

    setLoading(true);

    const formData = new FormData();
    formData.append('video', selectedVideo);

    try {
      const res = await axios.post('http://localhost:5010/detect_object_in_video', formData, {
        responseType: 'blob',
      });

      const outputURL = URL.createObjectURL(res.data);
      setOutputVideoURL(outputURL); // ✅ only update the state
    } catch (err) {
      console.error("Prediction failed:", err);
      alert("Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="video-detect-container">
      <h2>Object Detection in Video using YOLOv8</h2>

      <input
        type="file"
        accept="video/*"
        onChange={handleVideoChange}
        className="file-input"
      />

      {previewURL && (
        <div className="video-preview">
          <h4>Selected Video Preview:</h4>
          <video src={previewURL} controls width="400" />
        </div>
      )}

      <button onClick={handlePredict} disabled={loading} className="predict-button">
        {loading ? "Processing..." : "Detect Objects"}
      </button>

      {outputVideoURL && (
        <div className="result-preview">
          <h4>Detected Video Output:</h4>
          <video
            key={outputVideoURL}
            src={outputVideoURL}
            controls
            autoPlay
            width="500"
          />
          <br />
          <a href={outputVideoURL} download="detected_video.mp4">
            Download Processed Video
          </a>
        </div>
      )}
    </div>
  );
}

export default Detect_object_in_vedio;
