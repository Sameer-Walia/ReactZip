// const OpenAI = require('openai').default;
// const openai = new OpenAI({
//     apiKey: process.env.OPENAI_API_KEY
// });

// app.post("/api/chat", async (req, res) =>
// {
//     try
//     {
//         const { message } = req.body;

//         const completion = await openai.chat.completions.create({
//             model: 'gpt-3.5-turbo',
//             messages: [{ role: 'user', content: message }]
//         });

//         res.json({ reply: completion.choices[0].message.content });
//     }
//     catch (error)
//     {
//         if (error.response)
//         {
//             console.error("OpenAI API error:", error.response.data);
//         } else
//         {
//             console.error("Error:", error.message);
//         }
//         res.status(500).json({ reply: "Something went wrong!" });
//     }
// });