import React, { useState } from 'react';
import axios from 'axios';

function Detect_object_in_image() {
  const [selectedImage, setSelectedImage] = useState(null);
  const [previewURL, setPreviewURL] = useState(null);
  const [outputImageURL, setOutputImageURL] = useState(null);
  const [loading, setLoading] = useState(false);

  function handleImageChange(e) {
        const file = e.target.files[0];
        setSelectedImage(file);
        setOutputImageURL(null); // Clear old output
        setPreviewURL(URL.createObjectURL(file));
    }

  const handlePredict = async () => 
{

    if (!selectedImage) 
    {
        alert("Please upload an image first.");
        return;
    }

    setLoading(true);

    // Prepare form data for the POST request
    const formData = new FormData();
    formData.append('image', selectedImage);

// You can now use this formData in an axios/fetch request


    try {
    // A Blob (Binary Large Object) is a data type used to store binary data — like images, videos, audio, or other files. So when you write:
      const res = await axios.post('http://localhost:5010/detect_object_in_image', formData, //  Sends: Image (from React to Flask).
      {
        responseType: 'blob', // // Receives image (from Flask to React as blob).
      });
      
    // you're telling Axios: "I'm expecting a binary file, not JSON or plain text. Treat the response as a file."
    // you're telling Axios: Hey! I'm expecting the server (Flask) to send back a binary file, not text or JSON

      const outputURL = URL.createObjectURL(res.data);
      setOutputImageURL(outputURL);
    } catch (err) {
      console.error("Prediction failed:", err);
      alert("Something went wrong with prediction.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="digit-container">
      <h2 className="title" >Object Detection using YOLOv8</h2>

      <input 
        type="file" 
        onChange={handleImageChange} 
        accept="image/*" 
        className="file-input" 
      />

        {
            previewURL ? 
                <div div className="image-preview">
                <img src={previewURL} alt="Selected" width="300"  style={{ width: '224px', height: '224px', objectFit: 'cover' }} />
                </div>
            :null
        }

      <div className="button-wrapper">
            <button onClick={handlePredict} disabled={loading} className="predict-button">
                {loading ? "Predicting..." : "Predict"}
            </button>
      </div>

      {
        outputImageURL && (
            <div className="prediction-result">
            <h4>Predicted Output:</h4><br/>
            <img src={outputImageURL} alt="Prediction Result" width="450" height="350"/>
            </div>
      )}
    </div>
  );
}

export default Detect_object_in_image;

