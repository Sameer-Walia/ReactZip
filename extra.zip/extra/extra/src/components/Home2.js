import React from 'react'
import { Link } from 'react-router-dom'
import Typewriter from './Typewriter';
import Footer from './Footer';

function Home2() {
    return (
        <div>
            <marquee className="marquee" behavior="scroll" scrollamount="20" >
                <p>
                    📊 Welcome to the Feedback Portal for Educational Institutions! &nbsp; 💡 Empowering Teachers Through Actionable Feedback! &nbsp; 📋 Analyze Teacher Performance with In-Depth Feedback Reports! &nbsp; ⏱️ Real-Time Feedback Analysis for Continuous Improvement!
                </p>
            </marquee>

            <div id="type" class="pd theme2">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <h1 class="mt-4 hd ph">WELCOME TO <span className='ccc'><Typewriter /></span></h1>

                            <p class="pp ps my-4">"Empowering education with student feedback. Analyze and improve teacher performance to enhance learning experiences."</p>

                            <Link to="/signup" className="btn btn2 ">Register</Link>
                            <Link to="/login" className="btn btn1 mx-3">Login</Link>

                        </div>
                        <div class="col-lg-6 col-12 mt-lg-0 mt-5">
                            <img src="assets/images/inter.png" class="img-fluid " />
                        </div>
                    </div>
                </div>
            </div>

            <div class="custom-background">
                <div class="custom-text-center">
                    <h1 class="custom-title">Write Your Feedback Now!</h1>
                    <h2 class="custom-subtitle">Empowering Teachers Through Actionable Feedback!</h2>
                    <div class="custom-buttons">
                        <Link to="/login" class="custom-button-start" href="/login">Get started now</Link>
                        <Link class="custom-button-contact" >Contact Us</Link>
                    </div>
                </div>
            </div>

            <div id="products" className='pd bg theme2'>
                <div class="container">
                    <h1 className='hd text-center col-lg-5 col-9 mx-auto'>To design and deliver the innovative products.</h1>
                    <div class="row mt-5">
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="pro rounded pr1 theme1">
                                <h1 class="counter">1058</h1>
                                <h3>Augmented Reality</h3>
                                <p>Lorem ipsum dolor sit amet elit et. Debitis nam, minima iste ipsum.</p>
                                <Link>Read More</Link>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mt-md-0 mt-5">
                            <div class="pro rounded pr2 theme1">
                                <h1 class="counter">874</h1>
                                <h3>Deep Expertise</h3>
                                <p>Lorem ipsum dolor sit amet elit et. Debitis nam, minima iste ipsum.</p>
                                <Link>Read More</Link>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12 mt-lg-0 mt-5 mx-auto">
                            <div class="pro rounded pr3 theme1">
                                <h1 class="counter">2345</h1>
                                <h3>Software development</h3>
                                <p>Lorem ipsum dolor sit amet elit et. Debitis nam, minima iste ipsum.</p>
                                <Link>Read More</Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <Footer />

            <Link to="#header" className="arrow"><i class="fa-solid fa-arrow-up-from-bracket"></i></Link>

        </div>

    )
}

export default Home2
