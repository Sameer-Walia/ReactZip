import React from 'react'
import { Link } from 'react-router-dom'

function Div() {

    return (
        <div id='feedback' className='pd theme2 px-4'>
            <h1 className='hd text-center mt-4 feedhd '>Select the teacher for feedback</h1>
            <img src="assets/images/line1.svg " alt="underline" className="feedbackline" />
            <div class="row ">
                <div class="col-lg-4 col-sm-6 col-12  marg">
                    <div class="feed">

                        <div className="profile-container">
                            <div className="profile-background"></div>
                            <img className="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                        </div>
                        <div className="card-content  text-center">

                            <img className='comma1' src="/assets/images/comma.png" />
                            <h3 className='pname'>Dr Geeta Mam</h3>
                            <img className='comma2' src="/assets/images/comma2.png" />

                            <p><strong>Department:</strong> B.Tech Computer Science Engineering</p>
                            <p><strong>Subject Name:</strong> Flat</p>
                            <p><strong>Subject Code:</strong> BTSE 351-32</p>

                            <Link to=""><button className="feedback-button">Give Feedback</button></Link>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-12  marg">
                    <div class="feed">

                        <div className="profile-container">
                            <div className="profile-background"></div>
                            <img className="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                        </div>
                        <div className="card-content  text-center">

                            <img className='comma1' src="/assets/images/comma.png" />
                            <h3 className='pname'>Dr Geeta Mam</h3>
                            <img className='comma2' src="/assets/images/comma2.png" />

                            <p><strong>Department:</strong> B.Tech Computer Science Engineering</p>
                            <p><strong>Subject Name:</strong> Flat</p>
                            <p><strong>Subject Code:</strong> BTSE 351-32</p>

                            <Link to=""><button className="feedback-button">Give Feedback</button></Link>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-12 marg">
                    <div class="feed">

                        <div className="profile-container">
                            <div className="profile-background"></div>
                            <img className="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                        </div>
                        <div className="card-content  text-center">

                            <img className='comma1' src="/assets/images/comma.png" />
                            <h3 className='pname'>Dr Geeta Mam</h3>
                            <img className='comma2' src="/assets/images/comma2.png" />

                            <p><strong>Department:</strong> B.Tech Computer Science Engineering</p>
                            <p><strong>Subject Name:</strong> Flat</p>
                            <p><strong>Subject Code:</strong> BTSE 351-32</p>

                            <Link to=""><button className="feedback-button">Give Feedback</button></Link>

                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6 col-12 marg">
                    <div class="feed">

                        <div className="profile-container">
                            <div className="profile-background"></div>
                            <img className="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                        </div>
                        <div className="card-content  text-center">

                            <img className='comma1' src="/assets/images/comma.png" />
                            <h3 className='pname'>Dr Geeta Mam</h3>
                            <img className='comma2' src="/assets/images/comma2.png" />

                            <p><strong>Department:</strong> B.Tech Computer Science Engineering</p>
                            <p><strong>Subject Name:</strong> Flat</p>
                            <p><strong>Subject Code:</strong> BTSE 351-32</p>

                            <Link to=""><button className="feedback-button">Give Feedback</button></Link>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-12 marg">
                    <div class="feed">

                        <div className="profile-container">
                            <div className="profile-background"></div>
                            <img className="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                        </div>
                        <div className="card-content  text-center">

                            <img className='comma1' src="/assets/images/comma.png" />
                            <h3 className='pname'>Dr Geeta Mam</h3>
                            <img className='comma2' src="/assets/images/comma2.png" />

                            <p><strong>Department:</strong> B.Tech Computer Science Engineering</p>
                            <p><strong>Subject Name:</strong> Flat</p>
                            <p><strong>Subject Code:</strong> BTSE 351-32</p>

                            <Link to=""><button className="feedback-button">Give Feedback</button></Link>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-12 marg">
                    <div class="feed">

                        <div className="profile-container">
                            <div className="profile-background"></div>
                            <img className="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                        </div>
                        <div className="card-content  text-center">

                            <img className='comma1' src="/assets/images/comma.png" />
                            <h3 className='pname'>Dr Geeta Mam</h3>
                            <img className='comma2' src="/assets/images/comma2.png" />

                            <p><strong>Department:</strong> B.Tech Computer Science Engineering</p>
                            <p><strong>Subject Name:</strong> Flat</p>
                            <p><strong>Subject Code:</strong> BTSE 351-32</p>

                            <Link to=""><button className="feedback-button">Give Feedback</button></Link>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Div
