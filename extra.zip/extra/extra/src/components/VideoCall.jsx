import { ZegoUIKitPrebuilt } from "@zegocloud/zego-uikit-prebuilt";

const VideoCall = () =>
{

    const roomID = window.location.pathname.split("/")[2];
    // Example URL: /call/12345 → room id = 12345

    const myMeeting = async (element) =>
    {
        const appID = 87085543;        // 🔥 Replace with your App ID
        const serverSecret = "adc62534af2aaa4a567b1451aa586de6"; // 🔥 Replace with your Server Secret

        // Generate a token
        const kitToken = ZegoUIKitPrebuilt.generateKitTokenForTest(
            appID,
            serverSecret,
            roomID,
            Date.now().toString(), // unique user id
            "User"                 // display name
        );

        const ui = ZegoUIKitPrebuilt.create(kitToken);

        ui.joinRoom({
            container: element,
            sharedLinks: [
                {
                    name: "Copy Link",
                    url: `${window.location.origin}/call/${roomID}`,
                },
            ],
            scenario: {
                mode: ZegoUIKitPrebuilt.VideoConference, // Group Call (supports many users)
            },
        });
    };

    return (
        <div
            ref={myMeeting}
            style={{ width: "100%", height: "100vh" }}
        ></div>
    );
};

export default VideoCall;
