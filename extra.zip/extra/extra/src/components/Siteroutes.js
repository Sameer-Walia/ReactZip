import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Home from './Home'
import Home2 from './Home2'
import Utube from './Utube'
import Gallery1 from './Gallery1'
import Gallery2 from './Gallery2'
import Gallery3 from './Gallery3'
import Utube2 from './Utube2'
import OwlCrousel1 from './OwlCrousel1'
import OwlCrousel2 from './OwlCrousel2'
import OwlCrousel3 from './OwlCrousel3'
import OwlCrousel4 from './OwlCrousel4'
import OwlCrousel5 from './OwlCrousel5'
import Form1 from './Form1'
import Zoomple from './Zoomple'
import Form2 from './Form2'
import Div from './Div'
import Vedio from './Vedio'
import Home3 from './Home3'
import Tasks from './Tasks'
import Divbox from './Divbox'
import Model from './Model'
import Chart from './Chart'
import Chart2 from './Chart2'
import AI_Model from './AI_Model'
import Number_Detect from './Number_Detect'
import Cloth_Detect from './Cloth_Detect'
import Image_detect from './Image_detect'
import Detect_object_in_image from './Detect_object_in_image'
import Detect_object_in_vedio from './Detect_object_in_vedio'
import Similiar_words from './Similiar_words'
import Email from './Email'
import ImagePredictor from './ImagePredictor'
import WebsocketChat from './WebsocketChat'
import VideoCallButton from './VideoCallButton'
import VideoCall from './VideoCall'

function Siteroutes() 
{
  return (
    <div>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/home2" element={<Home2 />}></Route>
        <Route path="/home3" element={<Home3 />}></Route>
        <Route path="/utube" element={<Utube />}></Route>
        <Route path="/utube2" element={<Utube2 />}></Route>
        <Route path="/gallery1" element={<Gallery1 />}></Route>
        <Route path="/gallery2" element={<Gallery2 />}></Route>
        <Route path="/gallery3" element={<Gallery3 />}></Route>
        <Route path="/owl1" element={<OwlCrousel1 />}></Route>
        <Route path="/owl2" element={<OwlCrousel2 />}></Route>
        <Route path="/owl3" element={<OwlCrousel3 />}></Route>
        <Route path="/owl4" element={<OwlCrousel4 />}></Route>
        <Route path="/owl5" element={<OwlCrousel5 />}></Route>
        <Route path="/form1" element={<Form1 />}></Route>
        <Route path="/login" element={<Form2 />}></Route>
        <Route path="/register" element={<Form2 />}></Route>
        <Route path="/zoomple" element={<Zoomple />}></Route>
        <Route path="/div" element={<Div />}></Route>
        <Route path="/vedio" element={<Vedio />}></Route>
        <Route path="/tasks" element={<Tasks />}></Route>
        <Route path="/divbox" element={<Divbox />}></Route>
        <Route path="/model" element={<Model />}></Route>
        <Route path="/chart" element={<Chart />}></Route>
        <Route path="/chart2" element={<Chart2 />}></Route>
        <Route path="/aimodel" element={<AI_Model />}></Route>
        <Route path="/number_detect" element={<Number_Detect />}></Route>
        <Route path="/cloth_detect" element={<Cloth_Detect />}></Route>
        <Route path="/image_detect" element={<Image_detect />}></Route>
        <Route path="/image_detect2" element={<ImagePredictor />}></Route>
        <Route path="/detect_object_in_image" element={<Detect_object_in_image />}></Route>
        <Route path="/detect_object_in_video" element={<Detect_object_in_vedio />}></Route>
        <Route path="/similiar_words" element={<Similiar_words />}></Route>
        <Route path="/email" element={<Email />}></Route>
        <Route path="/websocketchat" element={<WebsocketChat />}></Route>
        <Route path="/videocall" element={<VideoCallButton />}></Route>
        <Route path="/call/:roomID" element={<VideoCall />} />
      </Routes>
    </div>
  )
}

export default Siteroutes
