import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Scatter } from 'react-chartjs-2';
import {
    Chart as ChartJS, PointElement, LinearScale, Title, Tooltip, Legend
} from 'chart.js';

ChartJS.register(PointElement, LinearScale, Title, Tooltip, Legend);

function Chart2() {
    const [scatterData, setScatterData] = useState(null);

    useEffect(() => {
        fetchScatterData();
    }, []);

    const fetchScatterData = async () => {
        try {
            const res = await axios.get('http://localhost:5001/api/bivariate');
            setScatterData(res.data);
        } catch (err) {
            console.error('Error fetching scatter data:', err);
        }
    };

    const createScatterDataset = (label, data, xKey, yKey) => ({
        datasets: [{
            label,
            data: data.map(item => ({ x: item[xKey], y: item[yKey] })),
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
        }]
    });

    return (
        <>
            {
                scatterData ?
                    <div>
                        <h1 className='text-center margin-chart mb-4'>Bivariate Analysis</h1>

                        <div className="scatter-container">

                            <div className="chart-card">
                                <h4>Year vs Selling Price</h4>
                                <Scatter data={createScatterDataset('Year vs Price', scatterData.Year_vs_Selling_Price, 'Year', 'Selling_Price')} />
                            </div>

                            <div className="chart-card">
                                <h4>Present Price vs Selling Price</h4>
                                <Scatter data={createScatterDataset('Present Price vs Price', scatterData.Present_vs_Selling_Price, 'Present_Price', 'Selling_Price')} />
                            </div>

                            <div className="chart-card">
                                <h4>Kms Driven vs Selling Price</h4>
                                <Scatter data={createScatterDataset('Kms vs Price', scatterData.Kms_vs_Selling_Price, 'Kms_Driven', 'Selling_Price')} />
                            </div>
                        </div>
                    </div>
                    :<p>Loading scatter plots...</p>
            }
        </>
    );
}

export default Chart2;
