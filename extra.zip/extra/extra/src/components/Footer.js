import React from 'react'
import { Link } from 'react-router-dom'

function Footer() {
    return (
        <div>
            <div id="footer" class="pd">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-12">
                            <Link class="navbar-brand col-3" to="/"><h3><span><i class="fa-solid fa-graduation-cap sr1"></i></span>&nbsp;HIREIQ</h3></Link>
                            <p class="pg">We are Creative. World's best IT service company. Get the most of reduction in your team’s operating creates amazing UI/UX experiences.</p>
                            <a href=""><i class="fa-brands fa-twitter"></i></a>
                            <a href=""><i class="fa-brands fa-facebook"></i></a>
                            <a href=""><i class="fa-brands fa-instagram"></i></a>
                            <a href=""><i class="fa-brands fa-linkedin"></i></a>
                        </div>
                        <div class="col-lg-2 col-md-6 col-6  mt-md-0 mt-5">
                            <h3 class="pb-3">Navigation</h3>
                            <ul class="list-unstyled">
                                <li><a href="">About Us</a></li>
                                <li><a href="">Blog posts</a></li>
                                <li><a href="">Services</a></li>
                                <li><a href="">Contact us</a></li>
                                <li><a href="">Components</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-2 col-md-6 col-6 mt-lg-0 mt-5">
                            <h3 class="pb-3">Resources</h3>
                            <ul class="list-unstyled">
                                <li><a href="">Marketing Plans</a></li>
                                <li><a href="">Digital Services</a></li>
                                <li><a href="">interior Design</a></li>
                                <li><a href="">Product Selling</a></li>
                                <li><a href="">Digital Services</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12  mt-lg-0 mt-5">
                            <h3 class="pb-3">Contact Info</h3>
                            <ul class="list-unstyled">
                                <li>Address : <a href="">Excellence Solutions, 343 marketing, #2214 cravel street, NY - 62617.</a></li>
                                <li>Phone : <a href="">+1(21) 234 4567</a></li>
                                <li>Email : <a href="">info@example.com</a></li>
                                <li>Support : <a href="">info@support.com</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="bb"></div>
                <div><p class="pg pt-5 text-center">© 2021 Excellence. All rights reserved. Design by Sameer</p></div>
            </div>
        </div >
    )
}

export default Footer
