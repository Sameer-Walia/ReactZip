import { useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

function AI_Model() {
    const [image, setImage] = useState(null);
    const [imagePreview, setImagePreview] = useState(null); // for preview
    const [prediction, setPrediction] = useState(null);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setImage(file);

        // Set image preview URL
        if (file) {
            setImagePreview(URL.createObjectURL(file));
        } else {
            setImagePreview(null);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!image) {
            alert("Please upload an image.");
            return;
        }

        const formData = new FormData();
        formData.append('file', image);

        try {
            const response = await axios.post('http://localhost:5003/predict', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            setPrediction(response.data);
        } catch (error) {
            console.error("Error during prediction:", error);
            toast.warn("Failed to get prediction.");
        }
    };

    return (
        <div className="ai-container">
            <form onSubmit={handleSubmit} className="ai-form mr">
                <h2 className="ai-title">🌿 Plant Disease Detection</h2>

                <input type="file" accept="image/*" onChange={handleImageChange} className="ai-input" />
                {/* {imagePreview && (
                    <div>
                        <p><strong>Selected Image:</strong></p>
                        <img
                            src={imagePreview}
                            alt="Preview"
                            style={{ maxWidth: "300px", maxHeight: "300px", marginBottom: "15px", borderRadius: "10px", border: "1px solid #ccc" }}
                        />
                    </div>
                )} */}

                {/* If imagePreview has a value (i.e., not null, undefined, or false), then show the <div> block.” */}
                {/* If imagePreview = null or undefined → it renders nothing. */}

                {/* both are correct */}

                {
                    imagePreview ? 
                        <div>
                            <p><strong>Selected Image:</strong></p>
                            <img
                                src={imagePreview}
                                alt="Preview"
                                style={{ maxWidth: "300px", maxHeight: "300px", marginBottom: "15px", borderRadius: "10px", border: "1px solid #ccc" }}
                            />
                        </div>
                    : null
                }


                <button type="submit" className="ai-button">Predict</button><br />

                {prediction && (
                    <div>
                        <p className="ai-result">🩺 <strong>Disease:</strong> {prediction.predicted_class}</p>
                        <p><strong>Confidence:</strong> {prediction.confidence}</p>
                        <p><strong>Message:</strong> {prediction.message}</p>
                    </div>
                )}
            </form>
        </div>
    );
}

export default AI_Model;
