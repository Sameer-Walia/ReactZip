import React from 'react'
import Footer from './Footer'

function Gallery2() {
  return (
    <div>
      <section id="gallery" className='theme1'>
        <div class="container">
          <p class="text-center hd mt-5 ">Various Photos Of Nauvaraha(CSS and JS code)</p>
          <h1 class="text-center pg mb-3">PHOTO GALLERY 2</h1>
          <div id="image-gallery">
            <div class="row">
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 image">
                <div class="img-wrapper">
                  <a href="assets/images/blog3.jpg"><img src="assets/images/blog3.jpg" class="img-responsive"/></a>
                  <div class="img-overlay">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 image">
                <div class="img-wrapper">
                  <a href="assets/images/blog1.jpg"><img src="assets/images/blog1.jpg" class="img-responsive"/></a>
                  <div class="img-overlay">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 image">
                <div class="img-wrapper">
                  <a href="assets/images/blog2.jpg"><img src="assets/images/blog2.jpg" class="img-responsive"/></a>
                  <div class="img-overlay">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 image">
                <div class="img-wrapper">
                  <a href="assets/images/product1.jpg"><img src="assets/images/product1.jpg" class="img-responsive"/></a>
                  <div class="img-overlay">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 image">
                <div class="img-wrapper">
                  <a href="assets/images/service1.jpg"><img src="assets/images/service1.jpg" class="img-responsive"/></a>
                  <div class="img-overlay">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 image">
                <div class="img-wrapper">
                  <a href="assets/images/service2.jpg"><img src="assets/images/service2.jpg" class="img-responsive"/></a>
                  <div class="img-overlay">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 image">
                <div class="img-wrapper">
                  <a href="assets/images/service3.jpg"><img src="assets/images/service3.jpg" class="img-responsive"/></a>
                  <div class="img-overlay">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 image mb-5">
                <div class="img-wrapper">
                  <a href="assets/images/product2.jpg"><img src="assets/images/product2.jpg" class="img-responsive"/></a>
                  <div class="img-overlay">
                    <i class="fa fa-plus-circle" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}

export default Gallery2
