import React from 'react'
import { Link } from 'react-router-dom'

function Zoomple() {
    
    return (
        <div id="zoomple" className='pd theme1' >
            <div class="container">
                <h1 className='hd text-center p-4 '>Zoomple Effect</h1>
                <div className='pt-5'>
                    <a href="assets/images/p1.jpg" className='zoomple'><img src="assets/images/p1.jpg" alt="" class="small"/><br/></a>
                    <a href="assets/images/p2.jpg" className='zoomple'><img src="assets/images/p2.jpg" alt="" class="small"/><br/></a>
                    <a href="assets/images/p3.jpg" className='zoomple'><img src="assets/images/p3.jpg" alt="" class="small"/><br/></a>
                    <a href="assets/images/p4.jpg" className='zoomple'><img src="assets/images/p4.jpg" alt="" class="small"/><br/></a>
                    <a href="assets/images/p5.jpg" className='zoomple'><img src="assets/images/p5.jpg" alt="" class="small"/><br/></a>
                    <a href="assets/images/p6.jpg" className='zoomple'><img src="assets/images/p6.jpg" alt="" class="small"/></a>
                </div>
                <div class="box">
                    <img src="assets/images/p1.jpg" alt="" class="big" />
                </div>
            </div>
        </div>
    )
}

export default Zoomple
