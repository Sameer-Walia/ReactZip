import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

function Similiar_words() {
  const [word, setWord] = useState('');
  const [results, setResults] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try 
    {
      const response = await axios.post('http://localhost:5011/similar_words',
      {
        word: word.toLowerCase()  
        // word.toLowerCase() :  this converts the word to lowercase and then send to Flask because model only accept lower case words
      });
      setResults(response.data.similar);
    } 
    catch (err) 
    {
      toast.warn("Word is not Present. Will be added Soon")
    }
  };

  return (
    <div className="similar-container">
      <h2 className="similar-heading">🔍 Find Similar Words</h2>
      <form onSubmit={handleSubmit} className="similar-form">
        <input
          type="text"
          placeholder="Enter a word"
          value={word}
          onChange={(e) => setWord(e.target.value)}
          className="similar-input"
        />
        <button type="submit" className="similar-button">Search</button>
      </form>


      <ul className="similar-list">
        {
            results.map(([similarWord, score], index) => 
            <li key={index} className="similar-item">
                <span className="word">{similarWord}</span>
                <span className="score">{score.toFixed(3)}</span>
            </li>
           )
        }
      </ul>
    </div>
  );
}

export default Similiar_words;
