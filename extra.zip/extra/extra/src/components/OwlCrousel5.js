import React, { useEffect } from 'react'

function OwlCrousel5() {

    return (
        <div id='owl4' className='pd mt-5 theme2'>
            <div class="container">
                <div class="mhn-slide owl-carousel">
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/blog1.jpg" />
                            <div class="mhn-img"><div class="loader-circle"><div class="loader-stroke-left"></div><div class="loader-stroke-right"></div></div></div>
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/blog2.jpg" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/blog3.jpg" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/product1.jpg" alt="" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/product2.jpg" alt="" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/product3.jpg" alt="" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/service1.jpg" alt="" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/service2.jpg" alt="" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/service3.jpg" alt="" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/job1.jpg" alt="" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/job2.jpg" alt="" />
                        </div>
                    </div>
                    <div class="mhn-item">
                        <div class="mhn-inner">
                            <img src="assets/images/job3.jpg" alt="" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default OwlCrousel5

