import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelope, faLock } from '@fortawesome/free-solid-svg-icons'
import { Link } from 'react-router-dom'

function Login() {
    return (
        <div>
            <form class="register-form mt-5">

                <div class="input-container">

                    <input type="email" name="useremail" placeholder="" class="input-field" required />

                    <label class="input-label">
                        <span><FontAwesomeIcon icon={faEnvelope} /></span><span className='ps-2'>Email</span>
                    </label>

                </div>

                <div class="input-container mt-4">

                    <input type="password" name="useremail" placeholder="" class="input-field" required />

                    <label class="input-label">
                        <span><FontAwesomeIcon icon={faLock} /></span><span className='ps-2'>Password</span>
                    </label>

                </div>

                <input type="submit" className="register-button" value="Submit" />

                <p className="register-text ">
                    New Here? <Link to="/register" className="login-link" >Sign Up</Link>
                </p>

            </form>
        </div>
    )
}

export default Login
