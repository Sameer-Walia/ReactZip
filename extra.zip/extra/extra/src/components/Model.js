import { useState } from 'react';
import axios from 'axios';

function Model() {
    const [formData, setFormData] = useState({
        Year: '',
        Present_Price: '',
        Kms_Driven: '',
        Owner: '',
        Fuel_Type: '',
        Seller_Type: '',
        Transmission: ''
    });

    const [prediction, setPrediction] = useState();

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };
    
    // setFormData({ ...formData,  ( keep existing values ),  [e.target.name]: e.target.value ( update just the one field )});

    
    // formData: a state object that holds form values.
    // setFormData: the function to update that state.
    // { ...formData, ... }: this copies all existing values in the form (using the spread operator).
    // [e.target.name]: this allows dynamic key access — it updates only the field that triggered the change.
    // e.target.value: this is the new value typed by the user.

    async function handleSubmit(e)
    {
        e.preventDefault();
        try 
        {
            const res = await axios.post('http://localhost:5001/api/predict', formData);
            setPrediction(res.data.predicted_price);
        } 
        catch (err) 
        {
            console.error('Prediction failed:', err);
        }
    };

    return (
        <form className="form-container1" onSubmit={handleSubmit}>
            <h2 className="form-title1">Car Price Prediction</h2>

            <input className="form-input1" name="Year" onChange={handleChange} placeholder="Year" />

            <input className="form-input1" name="Present_Price" onChange={handleChange} placeholder="Present Price" />

            <input className="form-input1" name="Kms_Driven" onChange={handleChange} placeholder="Kms Driven" />

            <input className="form-input1" name="Owner" onChange={handleChange} placeholder="Owner Count" />

            <input className="form-input1" name="Fuel_Type" onChange={handleChange} placeholder="Fuel Type (petrol/diesel)" />

            <input className="form-input1" name="Seller_Type" onChange={handleChange} placeholder="Seller Type (dealer/individual)" />

            <input className="form-input1" name="Transmission" onChange={handleChange} placeholder="Transmission (manual/automatic)" />

            <button type="submit" className="form-button1">Predict</button>

            {
                prediction > 0 ?
                    <p className="form-result1">
                        You can sell the car for ₹ {prediction} Lakh
                    </p>
                    :null
            }

        </form>

    );
}

export default Model;
