import React, { useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBuilding, faEnvelope, faLock, faMobile, faPhone, faUser } from '@fortawesome/free-solid-svg-icons'
import { Link, useNavigate } from 'react-router-dom'

function Register()
{

    const [name, setname] = useState();
    const [phone, setphone] = useState();
    const [uname, setuname] = useState();
    const [pass, setpass] = useState();
    const [cpass, setcpass] = useState();
    const [terms, setterms] = useState(false);
    const [msg, setmsg] = useState();
    const [verrors, setverrors] = useState({});
    const [loading, setloading] = useState(false);
    const navi = useNavigate();


    return (
        <div>
            <form class="register-form mt-5">

                <div class="input-container">

                    <div class="row">
                        <div class="col-6">
                            <input type="text" name="username" placeholder="" onChange={(e) => setname(e.target.value)} className="input-field" required />
                            <label className="input-label ">
                                <span><FontAwesomeIcon icon={faUser} /></span><span className='ps-2'>Username</span>
                            </label>
                        </div>
                        <div class="col-6 input-container">
                            <input type="number" name="userrollno" onChange={(e) => setname(e.target.value)} placeholder="" className="input-field" required />
                            <label className="input-label">
                                <span className='ps-2'><FontAwesomeIcon icon={faMobile} /></span><span className='ps-2'>Roll No.</span>
                            </label>
                        </div>
                    </div>

                </div>

                <div className="input-container mt-4">
                    <select
                        name="department"
                        className="input-field"
                        required
                        onChange={(e) => setname(e.target.value)}
                    >
                        <option value="">Choose Department</option>
                        <option value="B.Tech Computer Science Engineering">B.Tech Computer Science Engineering</option>
                        <option value="B.Tech Electronics and Communication Engineering">B.Tech Electronics and Communication Engineering</option>
                        <option value="B.Tech Mechanical Engineering">B.Tech Mechanical Engineering</option>
                    </select>

                    <label className="input-label">
                        <span><FontAwesomeIcon icon={faBuilding} /></span><span className='ps-2'>Department</span>
                    </label>
                </div>

                <div class="input-container mt-4">

                    <div class="row">
                        <div class="col-6">
                            <input type="tel" name="usernumber" onChange={(e) => setname(e.target.value)} placeholder="" className="input-field" />
                            <label className="input-label">
                                <span><FontAwesomeIcon icon={faPhone} /></span><span className='ps-2'>Phone</span>
                            </label>
                        </div>
                        <div class="col-6 input-container ">
                            <select
                                name="department"
                                className="input-field"
                                required
                                onChange={(e) => setname(e.target.value)}
                            >
                                <option value="">Choose Semester</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                            </select>

                            <label className="input-label ps-2">
                                <span><FontAwesomeIcon icon={faBuilding} /></span><span className='ps-2'>Semester</span>
                            </label>
                        </div>
                    </div>

                </div>

                <div class="input-container mt-4">

                    <input type="email" onChange={(e) => setname(e.target.value)} name="useremail" placeholder="" class="input-field" required />

                    <label class="input-label">
                        <span><FontAwesomeIcon icon={faEnvelope} /></span><span className='ps-2'>Email</span>
                    </label>

                </div>

                <div class="input-container mt-4">

                    <input type="password" onChange={(e) => setname(e.target.value)} name="useremail" placeholder="" class="input-field" required />

                    <label class="input-label">
                        <span><FontAwesomeIcon icon={faLock} /></span><span className='ps-2'>Password</span>
                    </label>

                </div>

                <div class="input-container mt-4">

                    <input type="password" name="useremail" onChange={(e) => setname(e.target.value)} placeholder="" class="input-field" required />

                    <label class="input-label">
                        <span><FontAwesomeIcon icon={faLock} /></span><span className='ps-2'>Confirm Password</span>
                    </label>

                </div>

                <label className="mt-4 cbx1">
                    <input type="checkbox" name="cbx1" onChange={(e) => setname(e.target.value)} /><i> </i>I accept the terms and conditions
                </label>

                <input type="submit" className="register-button" value="Submit" />

                <p className="register-text ">
                    Already registered? <Link to="/login" className="login-link" >Login</Link>
                </p>

            </form>
        </div>
    )
}

export default Register
