import React, { useState } from 'react';
import axios from 'axios';

function Email() {
  const [emailText, setEmailText] = useState('');
  const [result, setResult] = useState('');
  const [confidence, setConfidence] = useState('');


  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post('http://localhost:5017/email_spam_check', {
        email: emailText,
      });
      setResult(res.data.result);
      setConfidence(res.data.confidence);
    } catch (err) {
      console.error(err);
      setResult('Error: Could not predict');
    }
  };

  return (
    <div className="email-container">
      <h2 className="email-heading">Spam Email Detection Tool</h2>

      <form className="email-form" onSubmit={handleSubmit}>
        <label htmlFor="emailText" className="email-label">
          Enter email subject or message:
        </label>
        <textarea
          id="emailText"
          value={emailText}
          onChange={(e) => setEmailText(e.target.value)}
          placeholder="Paste email content here..."
          className="email-textarea"
          rows="6"
        ></textarea>
        <button type="submit" className="email-button">
          Check for Spam
        </button>
      </form>

      {result && (
        <p className="email-result">
            Result: <strong>{result}</strong><br />
            Confidence: <strong>{confidence}</strong>
        </p>
        )}
    </div>
  );
}

export default Email;

