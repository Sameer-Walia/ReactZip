import React from 'react'
import Login from './Login'
import { Link, useLocation } from 'react-router-dom';
import Register from './Register';


function Form2() {

    const location = useLocation();
    const path = location.pathname

    // Determine the active button based on the current URL path
    const activeButton = path === "/register" ? "register" : "login";

    return (
        <div id='form2' className='pd theme1'>
            <div class="container">
                <div class="row ">
                    <div class="col-lg-6 col-12">
                        <img src={`assets/images/login1.webp`} alt="" className="img-fluid images " />
                    </div>
                    <div class="col-lg-6 col-12 text-center ">
                        <div className={`containerdiv mt-5 `}>
                            <Link
                                to="/login"
                                className={`link ${activeButton === "login" ? "active" : "inactive"}`}
                                style={{ fontSize: "0.9rem" }}
                            >
                                Log in
                            </Link>
                            <Link
                                to="/register"
                                className={`link ${activeButton === "register" ? "active" : "inactive"}`}
                                style={{ fontSize: "0.9rem" }}
                            >
                                Register
                            </Link>
                        </div>

                        {
                            activeButton === "register" ? 
                            <>
                                <><Register/></>
                            </>:<Login/>
                        }

                    </div>
                </div>
            </div>
        </div>
    )
}

export default Form2
