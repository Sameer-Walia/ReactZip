import React, { useEffect, useState } from 'react'

function Vedio() {

    const [textIndex, setTextIndex] = useState(0);
    const [scrolled, setScrolled] = useState(false);

    const texts = ["Welcome to Our Site", "Explore Amazing Features", "Join Us Today"];

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 50);
        };
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    return (
        <div>
            <div className="homepage">
                <header className={scrolled ? "header scrolled" : "header"}></header>
                <video autoPlay loop muted className="background-video">
                    <source src="assets/vedio/ptuvid.mp4" type="video/mp4" />
                </video>
                <div className="content">
                    <button onClick={() => setTextIndex((textIndex - 1 + texts.length) % texts.length)}>
                        ◀
                    </button>
                    <h1>{texts[textIndex]}</h1>
                    <button onClick={() => setTextIndex((textIndex + 1) % texts.length)}>
                        ▶
                    </button>
                </div>
            </div>

        </div>
    )
}

export default Vedio
