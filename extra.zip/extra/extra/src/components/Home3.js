import React from 'react'
import { Link } from 'react-router-dom'

function Home3() {
    return (
        <div id='home3'>
            <header class="header">
                <div class="overlay">
                    <h1 class="title">Find Trusted Local Help for Any Task</h1>
                    <p class="description">Post a task and connect with skilled workers in your neighborhood.</p>
                    <input type="text" placeholder="What do you need help with?" class="input" />
                    <button class="button">Post a Task</button>
                </div>
            </header>

            <section class="how-it-works">
                <h2 class="section-title">How It Works</h2>
                <div class="steps-container">
                    <div class="step">
                        <h3 class="step-title">Post a Task</h3>
                        <p class="step-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    </div>
                    <div class="step">
                        <h3 class="step-title">Get Offers</h3>
                        <p class="step-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    </div>
                    <div class="step">
                        <h3 class="step-title">Select & Get It Done</h3>
                        <p class="step-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    </div>
                    <div class="step">
                        <h3 class="step-title">Payment & Review</h3>
                        <p class="step-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    </div>
                </div>
            </section>


            <section class="backcolor">
                <h2 class="section-title">Featured Tasks</h2>
                <div class="feature-container">
                    <div class="feature-step">
                        <h3 class="feature-Heading">Fix my leaking tap</h3>
                        <p class="feature-cost">$50 - $100 | New York, NY.</p>
                        <Link to="/" className='btn btn-primary'>Apply Now</Link>
                    </div>
                    <div class="feature-step">
                        <h3 class="feature-Heading">Help with moving furniture</h3>
                        <p class="feature-cost">$50 - $100 | New York, NY.</p>
                        <Link to="/" className='btn btn-primary'>Apply Now</Link>
                    </div>
                    <div class="feature-step">
                        <h3 class="feature-Heading">Lawn mowing service</h3>
                        <p class="feature-cost">$50 - $100 | New York, NY.</p>
                        <Link to="/" className='btn btn-primary'>Apply Now</Link>
                    </div>
                </div>
            </section>

            <section class="how-it-works">
                <h2 class="section-title">Why Choose Neibhrly?</h2>
                <div class="steps-container">
                    <div class="Choose">
                        <h3 class="step-title">Secure Payments</h3>
                        <p class="step-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    </div>
                    <div class="Choose">
                        <h3 class="step-title">Verified Taskers</h3>
                        <p class="step-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    </div>
                    <div class="Choose">
                        <h3 class="step-title">Local & Reliable</h3>
                        <p class="step-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    </div>
                    <div class="Choose">
                        <h3 class="step-title">Reviews & Ratings</h3>
                        <p class="step-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    </div>
                </div>
            </section>

            <section className="download-section">
                <h2 className="download-heading">Download the Neibhrly App</h2>
                <p className="download-text">Book and manage tasks on the go!</p>
                <div className="button-container">
                    <button className="google-play">Google Play</button>
                    <button className="app-store">App Store</button>
                </div>
            </section>


        </div>


    )
}

export default Home3
