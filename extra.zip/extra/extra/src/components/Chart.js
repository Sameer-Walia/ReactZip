import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, BarElement, CategoryScale, LinearScale, Legend, Tooltip } from 'chart.js';

ChartJS.register(BarElement, CategoryScale, LinearScale, Legend, Tooltip);

function ChartComparison() {
    const [chartData, setChartData] = useState();

    useEffect(() => {
        fetchchartdata()
    }, []);

    async function fetchchartdata() {
        try {
            const res = await axios.get('http://localhost:5001/api/univariate');
            setChartData(res.data);
        }
        catch (err) {
            console.error('Error fetching chart data:', err);
        }
    };


    const createBarData = (title, dataObj) => ({
        labels: Object.keys(dataObj),
        datasets: [{
            label: title,
            data: Object.values(dataObj),
            backgroundColor: 'rgba(75, 192, 192, 0.6)'
        }]
    });

    // if (!chartData) return <p>Loading charts...</p>;
    // or use below code

    return (
        <>
            {
                chartData ?
                    <div>
                        <h1 className='text-center margin-chart'>Bar Charts</h1>

                        <div className="chart-container mt-5">
                            <div className="chart-card">
                                <h3 className="chart-title">Fuel Type</h3>
                                <Bar data={createBarData('Fuel Type', chartData.Fuel_Type)} />
                            </div>
                            <div className="chart-card">
                                <h3 className="chart-title">Seller Type</h3>
                                <Bar data={createBarData('Seller Type', chartData.Seller_Type)} />
                            </div>
                            <div className="chart-card">
                                <h3 className="chart-title">Transmission</h3>
                                <Bar data={createBarData('Transmission', chartData.Transmission)} />
                            </div>
                        </div>
                    </div>
                    : <p>Loading charts...</p>
            }
        </>
    )

}

export default ChartComparison;
