import React, { useState } from 'react';
import axios from 'axios';

function Cloth_Detect() {
  const [image, setImage] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [prediction, setPrediction] = useState('');

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedImage(file);
      setImage(file);
    }
  };

  const handlePredict = async () => {
    const formData = new FormData();
    formData.append('image', image);

    try {
      const res = await axios.post('http://localhost:5006/predict_cloth', formData);
      setPrediction(res.data.prediction);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="digit-container">
      <h2 className="title">Cloth / Shoes Recognition</h2>
      
      <input 
        type="file" 
        onChange={handleImageChange} 
        accept="image/*" 
        className="file-input" 
      />

      {selectedImage && (
        <div className="image-preview">
          <img src={URL.createObjectURL(selectedImage)} alt="Uploaded" />
        </div>
      )}

      <div className="button-wrapper">
        <button onClick={handlePredict} className="predict-button">Predict</button>
      </div>

      {prediction !== '' && (
        <h3 className="prediction-result">Predicted Cloth: {prediction}</h3>
      )}
    </div>
  );
}

export default Cloth_Detect;

