import React from 'react'
import Footer from './Footer'

function Gallery1() {
    return (
        <div>
            <div id="gallery" class="pd theme1">
                <div class="container">
                    <p class="text-center hd mt-5">Various Photos Of Nauvaraha</p>
                    <h1 class="text-center pg mb-5">PHOTO GALLERY 1</h1>
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-12 ">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                                <a href="#exampleModal1"><img src="assets/images/blog3.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 1</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-md-0 mt-5 ">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal2">
                                <a href="#exampleModal2"><img src="assets/images/blog1.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 2</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-lg-0 mt-5 ">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal3">
                                <a href="#exampleModal3"><img src="assets/images/blog2.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 3</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-lg-0 mt-5">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal4">
                                <a href="#exampleModal4"><img src="assets/images/blog3.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 4</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal5">
                                <a href="#exampleModal5"><img src="assets/images/service1.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 5</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal6">
                                <a href="#exampleModal6"><img src="assets/images/service2.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 6</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal7">
                                <a href="#exampleModal7"><img src="assets/images/service3.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 7</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal8">
                                <a href="#exampleModal8"><img src="assets/images/service1.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 8</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal9">
                                <a href="#exampleModal9"><img src="assets/images/product1.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 9</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal10">
                                <a href="#exampleModal10"><img src="assets/images/product2.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 10</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal11">
                                <a href="#exampleModal11"><img src="assets/images/product3.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 11</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card" data-bs-toggle="modal" data-bs-target="#exampleModal12">
                                <a href="#exampleModal12"><img src="assets/images/product1.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 12</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card">
                                <a href=""><img src="assets/images/job1.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 13</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card">
                                <a href=""><img src="assets/images/job2.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 14</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card">
                                <a href=""><img src="assets/images/job3.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 15</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card">
                                <a href=""><img src="assets/images/job4.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 16</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card">
                                <a href=""><img src="assets/images/job5.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 17</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card">
                                <a href=""><img src="assets/images/job6.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 18</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5">
                            <div class="card">
                                <a href=""><img src="assets/images/job7.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 19</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-12 mt-5 mb-5">
                            <div class="card">
                                <a href=""><img src="assets/images/job8.jpg" class="card-img-top img-fluid" alt="..." /></a>
                                <div class="card-body">
                                    <h6 class="glhd">Pic 20</h6>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="modal fade" id="exampleModal1" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/blog3.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 1</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade " id="exampleModal2" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/blog1.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 2</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="exampleModal3" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/blog2.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 3</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="exampleModal4" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/blog3.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 4</h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="exampleModal5" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/service1.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 5</h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="exampleModal6" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/service2.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 6</h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="exampleModal7" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/service3.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 7</h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="exampleModal8" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/service1.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 8</h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="exampleModal9" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/product1.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 9</h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="exampleModal10" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/product2.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 10</h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="exampleModal11" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/product3.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 11</h6>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade " id="exampleModal12" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <img src="assets/images/product1.jpg" class="img-fluid" />
                            <h6 class="glhd">Pic 12</h6>
                        </div>
                    </div>
                </div>
            </div>

            <Footer/>
        </div>
    )
}

export default Gallery1
