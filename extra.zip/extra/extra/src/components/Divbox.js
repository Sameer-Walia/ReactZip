import React from 'react'

function Divbox() {
    return (
        <div id='divbox'>
            <h1 className="task-title">Select the teacher for feedback</h1>
            <div className='divpadding'>
                <div class="feature-container">
                    <div class="profile-card">
                        <div class="profile-image-container">
                            <img class="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                            <div class="profile-bg"></div>
                        </div>
                        <div class="profile-info">
                            <div className='tname'>
                                <img className='comma1' src="/assets/images/commat.png" />
                                <h2 className='mx-2'>Dr Dinesh Gupta</h2>
                                <img className='comma2' src="/assets/images/commat2.png" />
                            </div>

                            <p><strong className='headclr'>Department:</strong> Computer Science Engineering</p>
                            <p><strong className='headclr'>Subject Name:</strong> Data Structure & Algorithm</p>
                            <p><strong className='headclr'>Subject Code:</strong> BTCS 301-18</p>
                            <button class="give-feedback">Give Feedback</button>
                        </div>
                    </div>

                    <div class="profile-card">
                        <div class="profile-image-container">
                            <img class="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                            <div class="profile-bg"></div>
                        </div>
                        <div class="profile-info">
                            <div className='tname'>
                                <img className='comma1' src="/assets/images/commat.png" />
                                <h2 className='mx-2'>Dr Dinesh Gupta</h2>
                                <img className='comma2' src="/assets/images/commat2.png" />
                            </div>
                            <p><strong className='headclr'>Department:</strong> Computer Science Engineering</p>
                            <p><strong className='headclr'>Subject Name:</strong> Data Structure & Algorithm</p>
                            <p><strong className='headclr'>Subject Code:</strong> BTCS 301-18</p>
                            <button class="give-feedback">Give Feedback</button>
                        </div>
                    </div>

                    <div class="profile-card">
                        <div class="profile-image-container">
                            <img class="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                            <div class="profile-bg"></div>
                        </div>
                        <div class="profile-info">
                            <div className='tname'>
                                <img className='comma1' src="/assets/images/commat.png" />
                                <h2 className='mx-2'>Dr Dinesh Gupta</h2>
                                <img className='comma2' src="/assets/images/commat2.png" />
                            </div>
                            <p><strong className='headclr'>Department:</strong> Computer Science Engineering</p>
                            <p><strong className='headclr'>Subject Name:</strong> Data Structure & Algorithm</p>
                            <p><strong className='headclr'>Subject Code:</strong> BTCS 301-18</p>
                            <button class="give-feedback">Give Feedback</button>
                        </div>
                    </div>

                    <div class="profile-card">
                        <div class="profile-image-container">
                            <img class="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                            <div class="profile-bg"></div>
                        </div>
                        <div class="profile-info">
                            <div className='tname'>
                                <img className='comma1' src="/assets/images/commat.png" />
                                <h2 className='mx-2'>Dr Dinesh Gupta</h2>
                                <img className='comma2' src="/assets/images/commat2.png" />
                            </div>
                            <p><strong className='headclr'>Department:</strong> Computer Science Engineering</p>
                            <p><strong className='headclr'>Subject Name:</strong> Data Structure & Algorithm</p>
                            <p><strong className='headclr'>Subject Code:</strong> BTCS 301-18</p>
                            <button class="give-feedback">Give Feedback</button>
                        </div>
                    </div>

                    <div class="profile-card">
                        <div class="profile-image-container">
                            <img class="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                            <div class="profile-bg"></div>
                        </div>
                        <div class="profile-info">
                            <div className='tname'>
                                <img className='comma1' src="/assets/images/commat.png" />
                                <h2 className='mx-2'>Dr Dinesh Gupta</h2>
                                <img className='comma2' src="/assets/images/commat2.png" />
                            </div>
                            <p><strong className='headclr'>Department:</strong> Computer Science Engineering</p>
                            <p><strong className='headclr'>Subject Name:</strong> Data Structure & Algorithm</p>
                            <p><strong className='headclr'>Subject Code:</strong> BTCS 301-18</p>
                            <button class="give-feedback">Give Feedback</button>
                        </div>
                    </div>

                    <div class="profile-card">
                        <div class="profile-image-container">
                            <img class="profile-image" src="/assets/images/profile.jpg" alt="Profile" />
                            <div class="profile-bg"></div>
                        </div>
                        <div class="profile-info">
                            <div className='tname'>
                                <img className='comma1' src="/assets/images/commat.png" />
                                <h2 className='mx-2'>Dr Dinesh Gupta</h2>
                                <img className='comma2' src="/assets/images/commat2.png" />
                            </div>
                            <p><strong className='headclr'>Department:</strong> Computer Science Engineering</p>
                            <p><strong className='headclr'>Subject Name:</strong> Data Structure & Algorithm</p>
                            <p><strong className='headclr'>Subject Code:</strong> BTCS 301-18</p>
                            <button class="give-feedback">Give Feedback</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default Divbox
