import React, { useEffect } from 'react'

function OwlCrousel2() {

  return (
    <div id='owl2' className='pd mt-5 theme2'>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div id="news-slider" class="owl-carousel">
              <div class="post-slide " data-bs-toggle="modal" data-bs-target="#exampleModal1">
                <div class="post-img">
                  <img src="assets/images/blog1.jpg" alt="" />
                  <a href="#" class="over-layer"><i class="fa fa-link"></i></a>
                </div>
                <div class="post-content">
                  <h3 class="post-title">
                    <a href="#">Lorem ipsum dolor sit amet.</a>
                  </h3>
                  <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consectetur cumque dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
                  <span class="post-date"><i class="fa fa-clock-o"></i>Out 27, 2019</span>
                  <a href="#" class="read-more">read more</a>
                </div>
              </div>

              <div class="post-slide" data-bs-toggle="modal" data-bs-target="#exampleModal2" >
                <div class="post-img">
                  <img src="assets/images/blog2.jpg" alt="" />
                  <a href="#" class="over-layer"><i class="fa fa-link"></i></a>
                </div>
                <div class="post-content">
                  <h3 class="post-title">
                    <a href="#">Lorem ipsum dolor sit amet.</a>
                  </h3>
                  <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consectetur cumque dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
                  <span class="post-date"><i class="fa fa-clock-o"></i>Out 27, 2019</span>
                  <a href="#" class="read-more">read more</a>
                </div>
              </div>

              <div class="post-slide" data-bs-toggle="modal" data-bs-target="#exampleModal3">
                <div class="post-img">
                  <img src="assets/images/blog3.jpg" alt="" />
                  <a href="#" class="over-layer"><i class="fa fa-link"></i></a>
                </div>
                <div class="post-content">
                  <h3 class="post-title">
                    <a href="#">Lorem ipsum dolor sit amet.</a>
                  </h3>
                  <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consectetur cumque dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
                  <span class="post-date"><i class="fa fa-clock-o"></i>Out 27, 2019</span>
                  <a href="#" class="read-more">read more</a>
                </div>
              </div>

              <div class="post-slide" data-bs-toggle="modal" data-bs-target="#exampleModal4">
                <div class="post-img">
                  <img src="assets/images/product1.jpg" alt="" />
                  <a href="#" class="over-layer"><i class="fa fa-link"></i></a>
                </div>
                <div class="post-content">
                  <h3 class="post-title">
                    <a href="#">Lorem ipsum dolor sit amet.</a>
                  </h3>
                  <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consectetur cumque dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
                  <span class="post-date"><i class="fa fa-clock-o"></i>Out 27, 2019</span>
                  <a href="#" class="read-more">read more</a>
                </div>
              </div>

              <div class="post-slide" data-bs-toggle="modal" data-bs-target="#exampleModal5">
                <div class="post-img">
                  <img src="assets/images/product2.jpg" alt="" />
                  <a href="#" class="over-layer"><i class="fa fa-link"></i></a>
                </div>
                <div class="post-content">
                  <h3 class="post-title">
                    <a href="#">Lorem ipsum dolor sit amet.</a>
                  </h3>
                  <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consectetur cumque dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
                  <span class="post-date"><i class="fa fa-clock-o"></i>Out 27, 2019</span>
                  <a href="#" class="read-more">read more</a>
                </div>
              </div>

              <div class="post-slide" data-bs-toggle="modal" data-bs-target="#exampleModal6">
                <div class="post-img">
                  <img src="assets/images/product3.jpg" alt="" />
                  <a href="#" class="over-layer"><i class="fa fa-link"></i></a>
                </div>
                <div class="post-content">
                  <h3 class="post-title">
                    <a href="#">Lorem ipsum dolor sit amet.</a>
                  </h3>
                  <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consectetur cumque dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
                  <span class="post-date"><i class="fa fa-clock-o"></i>Out 27, 2019</span>
                  <a href="#" class="read-more">read more</a>
                </div>
              </div>

              <div class="post-slide" data-bs-toggle="modal" data-bs-target="#exampleModal7">
                <div class="post-img">
                  <img src="assets/images/service1.jpg" alt="" />
                  <a href="#" class="over-layer"><i class="fa fa-link"></i></a>
                </div>
                <div class="post-content">
                  <h3 class="post-title">
                    <a href="#">Lorem ipsum dolor sit amet.</a>
                  </h3>
                  <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consectetur cumque dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
                  <span class="post-date"><i class="fa fa-clock-o"></i>Out 27, 2019</span>
                  <a href="#" class="read-more">read more</a>
                </div>

              </div>

              <div class="post-slide" data-bs-toggle="modal" data-bs-target="#exampleModal8">
                <div class="post-img">
                  <img src="assets/images/service2.jpg" alt="" />
                  <a href="#" class="over-layer"><i class="fa fa-link"></i></a>
                </div>
                <div class="post-content">
                  <h3 class="post-title">
                    <a href="#">Lorem ipsum dolor sit amet.</a>
                  </h3>
                  <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consectetur cumque dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
                  <span class="post-date"><i class="fa fa-clock-o"></i>Out 27, 2019</span>
                  <a href="#" class="read-more">read more</a>
                </div>
              </div>

              <div class="post-slide" data-bs-toggle="modal" data-bs-target="#exampleModal9">
                <div class="post-img">
                  <img src="assets/images/service3.jpg" alt="" />
                  <a href="#" class="over-layer"><i class="fa fa-link"></i></a>
                </div>
                <div class="post-content">
                  <h3 class="post-title">
                    <a href="#">Lorem ipsum dolor sit amet.</a>
                  </h3>
                  <p class="post-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consectetur cumque dolorum, ex incidunt ipsa laudantium necessitatibus neque quae tempora......</p>
                  <span class="post-date"><i class="fa fa-clock-o"></i>Out 27, 2019</span>
                  <a href="#" class="read-more">read more</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" id="exampleModal1" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-fullscreen-sm-down">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <img src="assets/images/blog1.jpg" class="img-fluid" />
              <h6 class="hd">Pic 1</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade " id="exampleModal2" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <img src="assets/images/blog2.jpg" class="img-fluid" />
              <h6 class="hd">Pic 2</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModal3" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <img src="assets/images/blog3.jpg" class="img-fluid" />
              <h6 class="hd">Pic 3</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModal4" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <img src="assets/images/product1.jpg" class="img-fluid" />
              <h6 class="hd">Pic 4</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModal5" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <img src="assets/images/product2.jpg" class="img-fluid" />
              <h6 class="hd">Pic 5</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModal6" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <img src="assets/images/product3.jpg" class="img-fluid" />
              <h6 class="hd">Pic 6</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModal7" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <img src="assets/images/service1.jpg" class="img-fluid" />
              <h6 class="hd">Pic 7</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModal8" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <img src="assets/images/service2.jpg" class="img-fluid" />
              <h6 class="hd">Pic 8</h6>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModal9" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <img src="assets/images/service3.jpg" class="img-fluid" />
              <h6 class="hd">Pic 9</h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default OwlCrousel2

