import React, { useState } from 'react';
import { FaBars, FaTimes } from "react-icons/fa";
import { Link } from 'react-router-dom';

function Header1()
{
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div id='sahil'>
            <nav className="navbar2">
                <div className="nav-container">
                    <Link to="/home3" className="nav-logo">Neibhrly</Link>

                    <div className="nav-links">
                        <Link to="/home3" className="nav-link">Home</Link>
                        <Link to="/tasks" className="nav-link">Browse Tasks</Link>
                        <Link to="/divbox" className="nav-link">Post a Task</Link>
                        <Link to="/tasks/:id" className="nav-link">Task Details</Link>

                        {/* Dropdown for AI Model */}
                        <div className="nav-link dropdown">
                            <span>AI</span>
                            <div className="dropdown-content">
                                <Link to="/aimodel" className="dropdown-item">Plant Image Detection</Link>
                                <Link to="/number_detect" className="dropdown-item">Number Detection</Link>
                                <Link to="/cloth_detect" className="dropdown-item">Cloth Detection</Link>
                                <Link to="/image_detect" className="dropdown-item">Image Detection</Link>
                                <Link to="/image_detect2" className="dropdown-item">Image Detection 2</Link>
                                <Link to="/detect_object_in_image" className="dropdown-item">Detect Object in Image</Link>
                                <Link to="/detect_object_in_video" className="dropdown-item">Detect Object in Video</Link>
                                <Link to="/similiar_words" className="dropdown-item">Find Similiar Words</Link>
                                <Link to="/email" className="dropdown-item">Email Spam/Not Spam</Link>
                                <Link to="/websocketchat" className="dropdown-item">WebSocket Chatbox</Link>
                                <Link to="/videocall" className="dropdown-item">Video Call</Link>
                            </div>
                        </div>

                        <Link to="/model" className="nav-link">ML Model</Link>
                        <Link to="/chart" className="nav-link">Chart</Link>
                        <Link to="/chart2" className="nav-link">Chart2</Link>
                    </div>

                    <div className="nav-buttons">
                        <Link to="/login" className="btn login">Login</Link>
                        <Link to="/register" className="btn signup">Sign Up</Link>
                    </div>

                    <button className="nav-toggle" onClick={() => setIsOpen(!isOpen)}>
                        {isOpen ? <FaTimes /> : <FaBars />}
                    </button>
                </div>

                {isOpen &&
                    <div className="mobile-menu">
                        <Link to="/" className="mobile-link" onClick={() => setIsOpen(false)}>Home</Link>
                        <Link to="/tasks" className="mobile-link" onClick={() => setIsOpen(false)}>Browse Tasks</Link>
                        <Link to="/post-task" className="mobile-link" onClick={() => setIsOpen(false)}>Post a Task</Link>
                        <Link to="/dashboard" className="mobile-link" onClick={() => setIsOpen(false)}>Dashboard</Link>
                        <Link to="/contact" className="mobile-link" onClick={() => setIsOpen(false)}>Messages</Link>
                        <Link to="/profile" className="mobile-link" onClick={() => setIsOpen(false)}>Profile</Link>

                        <div className="mobile-buttons">
                            <Link to="/login" className="btn mobile-login" onClick={() => setIsOpen(false)}>Login</Link>
                            <Link to="/signup" className="btn mobile-signup" onClick={() => setIsOpen(false)}>Sign Up</Link>
                        </div>
                    </div>
                }
            </nav>
        </div>
    );
}

export default Header1;
