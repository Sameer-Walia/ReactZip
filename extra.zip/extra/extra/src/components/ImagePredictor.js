// ImagePredictor.jsx
import React, { useState } from "react";
import axios from "axios";

export default function ImagePredictor()
{
    const [file, setFile] = useState(null);
    const [predictions, setPredictions] = useState([]);
    const [loading, setLoading] = useState(false);

    const handleFileChange = (e) =>
    {
        setFile(e.target.files[0]);
        setPredictions([]); // reset previous predictions
    };

    const handleSubmit = async () =>
    {
        if (!file) return alert("Please select an image first!");
        const formData = new FormData();
        formData.append("image", file);

        try
        {
            setLoading(true);
            const res = await axios.post(
                "http://127.0.0.1:5000/predict_caption", // or /predict_caption   , predict_vit
                formData,
                { headers: { "Content-Type": "multipart/form-data" } }
            );
            setPredictions(res.data.predictions || [res.data.caption]);
        } catch (err)
        {
            console.error(err);
            alert("Error uploading image or getting prediction");
        } finally
        {
            setLoading(false);
        }
    };

    return (
        <div style={{ maxWidth: "500px", margin: "200px", textAlign: "center" }}>
            <h2>AI Image Predictor(not working , full code is taken from chatgpt but work is same as MobileNetV2 which i did)</h2>
            <input type="file" accept="image/*" onChange={handleFileChange} />
            <button onClick={handleSubmit} disabled={loading} style={{ marginLeft: 10 }}>
                {loading ? "Predicting..." : "Predict"}
            </button>

            {predictions.length > 0 && (
                <div style={{ marginTop: 20, textAlign: "left" }}>
                    <h3>Predictions:</h3>
                    <ul>
                        {predictions.map((p, idx) =>
                            p.class_idx !== undefined ? (
                                <li key={idx}>
                                    Class ID: {p.class_idx}, Probability: {p.probability.toFixed(3)}
                                </li>
                            ) : (
                                <li key={idx}>{p}</li>
                            )
                        )}
                    </ul>
                </div>
            )}
        </div>
    );
}
