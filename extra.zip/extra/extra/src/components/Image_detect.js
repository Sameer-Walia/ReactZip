import React, { useState } from 'react';
import axios from 'axios';

function Image_detect() {
  const [image, setImage] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [prediction, setPrediction] = useState('');
  const [confidence, setConfidence] = useState(null);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedImage(file);
      setImage(file);
    }
  };

  const handlePredict = async () => {
    const formData = new FormData();
    formData.append('image', image);

    try {
      const res = await axios.post('http://localhost:5008/predict_image', formData); // make sure route matches Flask
      setPrediction(res.data.prediction);
      setConfidence(res.data.confidence);
    } catch (err) {
      console.error('Prediction error:', err);
      setPrediction('Error during prediction');
      setConfidence(null);
    }
  };

  return (
    <div className="digit-container">
      <h2 className="title">Image Recognition</h2>
      
      <input 
        type="file" 
        onChange={handleImageChange} 
        accept="image/*" 
        className="file-input" 
      />

      {selectedImage && (
        <div className="image-preview">
          <img 
            src={URL.createObjectURL(selectedImage)} 
            alt="Uploaded" 
            style={{ width: '224px', height: '224px', objectFit: 'cover' }}
          />
        </div>
      )}

      <div className="button-wrapper">
        <button onClick={handlePredict} className="predict-button">Predict</button>
      </div>

      {prediction && (
        <h3 className="prediction-result">
          Predicted Label: <strong>{prediction}</strong><br />
          Confidence: <strong>{confidence !== null ? `${confidence * 100}%` : 'N/A'}</strong>
        </h3>
      )}
    </div>
  );
}

export default Image_detect;
