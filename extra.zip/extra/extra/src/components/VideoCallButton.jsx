import { useNavigate } from "react-router-dom";

function VideoCallButton()
{
    const navigate = useNavigate();

    const startCall = () =>
    {
        const roomId = Math.random().toString(36).substring(2, 10);
        navigate(`/call/${roomId}`);
        // navigate(`/call?roomId=${roomId}`);
    };

    return (
        <button
            onClick={startCall}
            style={{
                padding: "10px 20px",
                background: "blue",
                color: "white",
                borderRadius: "5px",
                marginTop: "250px",
                marginLeft: "650px"
            }}
        >
            Start Video Call
        </button>
    );
}

export default VideoCallButton;
