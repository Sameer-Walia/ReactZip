const mongoose = require('mongoose')

const ResetPassSechema = new mongoose.Schema({ username:String , exptime:Date , token:String} , { versionKey: false })

module.exports = mongoose.model("resetpass", ResetPassSechema, "resetpass");