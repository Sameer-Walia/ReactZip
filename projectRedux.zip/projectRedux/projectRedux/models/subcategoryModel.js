const mongoose = require('mongoose');

const SubCatSchema = new mongoose.Schema({ catid:{type: mongoose.Schema.Types.ObjectId, ref: 'category' } , subcatname: { type: String, unique: true }, subcatpic: String }, { versionKey: false })

module.exports = mongoose.model("subcategory", SubCatSchema, "subcategory");