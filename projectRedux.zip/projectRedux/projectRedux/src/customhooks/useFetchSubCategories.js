import axios from 'axios';
import { useEffect, useState } from 'react'
import { toast } from 'react-toastify';

function useFetchSubCategories(catid, edit=false) {

    const[subcatdata , setsubcatdata] = useState([]);
    const[loader , setloader] = useState(true);
    
    async function fetchsubcatbycat()
    {
        try
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/fetchsubcatbycatid?cid=${catid}`)
           
            if(resp.data.statuscode===1)
            {
                setsubcatdata(resp.data.subcatalldata)
            }
            else if(resp.data.statuscode===0)
            {
                setsubcatdata([]);
                toast.info("No subcategory found");
            }
            else
            {
                toast.error("Some error occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
        finally
        {
            setloader(false)
        }
    }
    
    useEffect(()=>
    {
        if(catid && edit===false)
        {
            fetchsubcatbycat();      
        }  
        else 
        {
            setsubcatdata([]); // reset when no category selected
        }
    },[catid , edit])


  return {subcatdata , setsubcatdata , loader , fetchsubcatbycat}
}

export default useFetchSubCategories;
