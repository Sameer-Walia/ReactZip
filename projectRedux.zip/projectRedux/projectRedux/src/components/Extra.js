import React, { useState } from 'react'
import { Link } from 'react-router-dom';

function Extra()
{
    const [storage, setstorage] = useState({ fno: 0, sno: 0 })
    const [sum, setsum] = useState()

    function handlechnage(evt)
    {
        const val = evt.target.value;
        setstorage({ ...storage, [evt.target.name]: val }) // The spread operator (...storage) keeps previous values so that updating one field doesn’t erase the other or used to quickly copy all or part of an existing array or object into another array or object
        // setstorage({...storage, fno: "5"})
        // setstorage({...storage, sno: "9"})
        // storage = { fno: "4", sno: "6" }
    }

    function handlesum()
    {
        setsum(Number(storage.fno) + Number(storage.sno))
    }

    return (
        <div>
            <div className="login">
                <div className="container">
                    <h2>Sum of 2 Number</h2>

                    {/* e refers to event like onchnage event
                    e.target refers to basically where the event occur like in which input field
                    e.target.value refers to value of field which we type */}

                    {/* below we pass only e , which means we pass all the event */}

                    <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
                        <input type="number" name="fno" placeholder="First Number" required onChange={(e) => handlechnage(e)} /><br />
                        <input type="number" name="sno" placeholder="Second Number" required onChange={(e) => handlechnage(e)} /><br />
                        <button onClick={handlesum} className='btn btn-primary'>Sum</button><br />
                        {sum}
                    </div>

                </div>
            </div>
        </div>
    )
}

export default Extra
