import { useState } from "react";
import { Link } from "react-router-dom";
import { CountrySelect , StateSelect , CitySelect, } from "react-country-state-city";

function OthersAppApi3() {
  const [country, setCountry] = useState(null);
  const [state, setState] = useState(null);
  const [city, setCity] = useState(null);

  return (
    <>
       <div className="breadcrumbs">
            <div className="container">
                <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                    <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                    <li className="active">3rd App Api</li>
                </ol>
            </div>
        </div>

        <div className="login">
            <div className="container">
                <h2>Country State City</h2>

                <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">

                    <form name="form1">   

                        <CountrySelect className="form-control" onChange={(e)=>{setCountry(e);setState(null);setCity(null);}} placeHolder="Select Country" /><br/>  

                        <StateSelect className="form-control" countryid={country?.id}  onChange={(e)=>{setState(e);setCity(null);}} placeHolder="Select State" /><br/>  

                        <CitySelect className="form-control" countryid={country?.id} stateid={state?.id} onChange={(e)=>setCity(e)} placeHolder="Select City" /><br/>  
                        
                        {country && state && city && 
                            <div className="selection-result text-center">
                                <h3>Selected Location</h3>
                                <p>Country: {country.name}</p>
                                <p>State: {state.name}</p>
                                <p>City: {city.name}</p>
                            </div>
                        }
                        
                    </form>
                </div>
                
            </div>
        </div><br/><br/><br/><br/>

    </>
  );
}

export default OthersAppApi3;
