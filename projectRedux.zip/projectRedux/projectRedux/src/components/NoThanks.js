import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { toast } from 'react-toastify'

function NoThanks() {

  const [uname, setUname] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);

  async function resendMail(e)
  {
    e.preventDefault()
    try 
    {
        setLoading(true);
        const data = { uname }
        const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/resendmail`, data );
        
        if(resp.data.statuscode===1)
        {
            toast.success("Activation mail resent successfully! , please check your mail");
            setUname("")
        }
        else if(resp.data.statuscode===2)
        {
            toast.warn("Activation mail not resent successfully!  , error while resending activation mail");
        }
        else if(resp.data.statuscode===0)
        {
            toast.warn(resp.data.msg)
        }
        else
        {
            toast.error("Some Problem Occured")
        }
    } 
    catch (e) 
    {
        toast.error("Error Occured " + e.message)
    } 
    finally 
    {
        setLoading(false);
    }
  };

  return (
    <div>
       <div className="breadcrumbs">
            <div className="container">
                <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                    <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                    <li className="active">No Thanks Page</li>
                </ol>
            </div>
        </div>

        <div className="login">
            <div className="container">

                {
                    showForm ? <h2>Resend Activation Mail Form</h2> :
                    <button onClick={() => setShowForm(true)} className="btn btn-primary">
                        Resend Activation Mail
                    </button>
                }

                {
                    showForm ?
                        <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
                            <form name="form1" onSubmit={resendMail}>
                                <div style={{ marginTop: "20px" }}>

                                    <input type="email" placeholder="Enter your registered email"  value={uname} onChange={(e) => setUname(e.target.value)} required/><br/>

                                    {
                                        loading? 
                                        <div className="loader-container">
                                            <img src="images/loader.gif" alt="loader" className="loader" />
                                        </div>:<input type="submit" name="btn" value="Resend Mail" className="btn btn-success" />
                                    }
                                </div>
                            </form>
                        </div>:null
                }<br/><br/>

                <p><strong>Thank you!</strong></p><br/>

            </div>
        </div>
    </div>
  )
}

export default NoThanks

