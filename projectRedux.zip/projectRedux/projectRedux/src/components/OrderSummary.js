import { useContext, useEffect, useState } from "react";
import { userContext } from "../App";
import axios from "axios";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";


function OrderSummary()
{
    const [orderinfo, setorderinfo] = useState();
    const [loading, setloading] = useState(false);
    const navi = useNavigate()

    const { isLoggedIn, username, name } = useSelector((state) => state.auth)
    const dispatch = useDispatch()

    async function fetchorderid()
    {
        try
        {
            setloading(true)
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/getorderid?un=${username}&name=${name}`)

            if (resp.data.statuscode === 1)
            {
                setorderinfo(resp.data.orderdata);
                toast.success("Order Details sent Successfully on Mail")
            }
            else if (resp.data.statuscode === 0)
            {
                toast.error("Error while fetching details")
            }
            else if (resp.data.statuscode === 2)
            {
                toast.error("Error while sending Order Details on Mail")
            }
            else
            {
                toast.error("Some error occured");
            }
        }
        catch (e)
        {
            toast.error("Error Occured " + e.message)
        }
        finally
        {
            setloading(false)
        }
    }

    useEffect(() =>
    {
        if (isLoggedIn === true)
        {
            fetchorderid();
        }
    }, [isLoggedIn])

    useEffect(() =>
    {
        if (sessionStorage.getItem("userdata") === null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
    }, [])

    useEffect(() =>
    {
        document.title = "Order Summary"
    }, [])


    return (
        <>
            <div className="login">
                <div className="container">
                    {
                        loading ? <><img src="images/loader.gif" alt="loader" className="loader" /></> : null
                    }
                    {
                        orderinfo &&
                        <>
                            <h2>Thanks for shopping on our website. Your order number is :-<br />{orderinfo._id}</h2>
                            <h2>
                                Your Order will be delivered at :-<br />
                                {orderinfo.address.house}, {orderinfo.address.area}, {orderinfo.address.city}, {orderinfo.address.state}
                            </h2>
                        </>
                    }

                </div>
            </div>
        </>
    )
}
export default OrderSummary;