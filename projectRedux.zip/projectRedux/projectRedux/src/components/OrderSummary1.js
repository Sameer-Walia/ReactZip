import { useContext, useEffect, useState } from "react";
import { userContext } from "../App";
import axios from "axios";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

function OrderSummary1()
{
    const { isLoggedIn, username, name } = useSelector((state) => state.auth)
    const dispatch = useDispatch()

    const [orderinfo, setorderinfo] = useState({});
    const navi = useNavigate()

    async function fetchorderid()
    {
        try
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/getorderid?un=` + username)

            if (resp.data.statuscode === 1)
            {
                setorderinfo(resp.data.orderdata);
            }
            else if (resp.data.statuscode === 0)
            {
                toast.error("Error while fetching details")
            }
            else
            {
                toast.error("Some error occured");
            }
        }
        catch (e)
        {
            toast.error("Error Occured " + e.message)
        }
    }

    useEffect(() =>
    {
        if (isLoggedIn === true)
        {
            fetchorderid();
        }
    }, [isLoggedIn])

    useEffect(() =>
    {
        if (sessionStorage.getItem("userdata") === null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
    }, [])

    useEffect(() =>
    {
        document.title = "Order Summary"
    }, [])


    return (
        <>
            <div className="login">
                <div className="container">

                    <h2>Thanks for shopping on our website. Your order number is :-<br />{orderinfo?._id}</h2>
                    <h2>
                        Your Order will be delivered at :-<br />
                        {orderinfo?.address?.house}, {orderinfo?.address?.area}, {orderinfo?.address?.city}, {orderinfo?.address?.state}
                    </h2>

                    {/* {
                        Object.keys(orderinfo).length>0?
                        <>
                            <h2>Thanks for shopping on our website. Your order number is :-<br/>{orderinfo?._id}</h2>
                            <h2>
                                Your Order will be delivered at :-<br />
                                {orderinfo.address.house}, {orderinfo.address.area}, {orderinfo.address.city}, {orderinfo.address.state}
                            </h2>
                        </>:null
                    } */}

                </div>
            </div>
        </>
    )
}
export default OrderSummary1;