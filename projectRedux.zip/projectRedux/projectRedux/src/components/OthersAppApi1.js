import axios from "axios";
import { useEffect, useState } from "react";
import {  Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function OthersAppApi1() { 

    const[data , setdata]=useState([]);
    const navi = useNavigate();


    async function fetchPost()
    {
        try
        {
            const resp = await axios.get(`https://jsonplaceholder.typicode.com/posts`)
            if(resp.status===200)
            {
                setdata(resp.data)
            }
            else
            {
                setdata([])
                toast.warn("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
    }

    
    useEffect(()=>
    {
        fetchPost();
    },[])


    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">3rd App Api</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    {
                        data.length>0?
                        <>
                            <h2>List Of Post</h2><br/>
                            <table className="table table-striped timetable_sub">
                                <tbody>
                                    <tr>
                                        <th>Userid</th>
                                        <th>id</th>
                                        <th>Title</th>
                                        <th>Body</th>
                                    </tr>
                                 </tbody>
                            {
                                data.map((item , index)=>
                                    <tr key={index}>
                                        <td>{item.userId}</td>
                                        <td>{item.id}</td>
                                        <td>{item.title}</td>
                                        <td>{item.body}</td>
                                    </tr>
                                )
                            }
                           
                            </table><br/><br/>
                            {data.length} Post found
                        </>:<h2>No Post Found</h2>
                    }
                </div>
            </div>

        </>
    )
}
export default OthersAppApi1;