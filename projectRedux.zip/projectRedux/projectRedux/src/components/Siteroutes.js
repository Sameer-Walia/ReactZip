import { Route, Routes, useLocation, useNavigate } from "react-router-dom";
import Signup from "./Signup";
import Home from "./Home";
import Login from "./Login";
import SearchUser from "./SearchUser";
import UsersList from "./UsersList";
import ManageCategory from "./ManageCategory";
import ManageSubCategory from "./ManageSubCategory";
import ManageProduct from "./ManageProduct";
import ChangePassword from "./ChangePassword";
import Categories from "./Categories";
import SubCategories from "./SubCategories";
import ProdDetails from "./ProdDetails";
import ProdDetails1 from "./ProdDetails1";
import ShowCart from "./ShowCart";
import CheckOut from "./CheckOut";
import OrderSummary from "./OrderSummary";
import ViewOrders from "./ViewOrders";
import UpdateStatus from "./UpdateStatus";
import OrderItems from "./OrderItems";
import UserOrderHistory from "./UserOrderHistory";
import SearchProducts from "./SearchProducts";
import AdminHome from "./AdminHome";
import SearchOrderId from "./SearchOrderId";
import ContactUs from "./ContactUs";
import AdminContactUs from "./AdminContactUs";
import AdminHeader from "./AdminHeader";
import Product from "./Product";
import UserRouteProtector from "./UserRouteProtector";
import AdminRouteProtector from "./AdminRouteProtector";
import ActivateAccount from "./ActivateAccount";
import Thanks from "./Thanks";
import NoThanks from "./NoThanks";
import OthersAppApi1 from "./OthersAppApi1";
import OthersAppApi2 from "./OthersAppApi2";
import ForgotPassword from "./ForgotPassword";
import ResetPassword from "./ResetPassword";
import OrderSummary1 from "./OrderSummary1";
import OthersAppApi2b from "./OthersAppApi2b";
import OthersAppApi3 from "./OthersAppApi3";
import ContactUs2 from "./ContactUs2";
import Extra from "./Extra";
import MyCookie from "./MyCookie";
import MyCookie2 from "./MyCookie2";
import Cookies from "universal-cookie";
import { useEffect } from "react";

function Siteroutes()
{
    const navi = useNavigate()
    const usercookie = new Cookies()
    const location = useLocation();

    useEffect(() =>
    {
        const cookieUser = usercookie.get("staysignin");
        if (cookieUser)
        {
            try
            {
                const publicPaths = ["/", "/login"];

                if (publicPaths.includes(location.pathname))
                {
                    if (cookieUser.usertype === "admin")
                    {
                        navi("/adminhome");
                    } else
                    {
                        navi("/home");
                    }
                }
            } catch (err)
            {
                console.error("Error parsing cookie user:", err);
            }
        }
    }, [location.pathname]);

    return (
        <>
            <Routes>
                <Route path="/" element={<Home />}></Route>
                <Route path="/home" element={<Home />}></Route>
                <Route path="/adminhome" element={<AdminRouteProtector compname={AdminHome} />}></Route>
                <Route path="/signup" element={<Signup />}></Route>
                <Route path="/thanks" element={<Thanks />}></Route>
                <Route path="/nothanks" element={<NoThanks />}></Route>
                <Route path="/activateaccount" element={<ActivateAccount />}></Route>
                <Route path="/login" element={<Login />}></Route>
                <Route path="/forgotpassword" element={<ForgotPassword />}></Route>
                {/* <Route path="/searchuser" element={<SearchUser />}></Route> */}
                <Route path="/searchuser" element={<AdminRouteProtector compname={SearchUser} />}></Route>
                <Route path="/userslist" element={<AdminRouteProtector compname={UsersList} />}></Route>
                <Route path="/managecategory" element={<AdminRouteProtector compname={ManageCategory} />}></Route>
                <Route path="/managesubcategory" element={<ManageSubCategory />}></Route>
                <Route path="/manageproduct" element={<ManageProduct />}></Route>
                <Route path="/changepassword" element={<UserRouteProtector compname={ChangePassword} />}></Route>
                <Route path="/category" element={<Categories />}></Route>
                <Route path="/subcategory" element={<SubCategories />}></Route>
                <Route path="/products" element={<Product />}></Route>
                {/* usercontext, udata and sessionstorage is there */}
                <Route path="/details" element={<ProdDetails />}></Route>
                {/* <Route path="/details1" element={<ProdDetails1/>}></Route> */}
                <Route path="/showcart" element={<ShowCart />}></Route>
                <Route path="/checkout" element={<CheckOut />}></Route>
                <Route path="/ordersummary" element={<OrderSummary />}></Route>
                {/* <Route path="/ordersummary" element={<OrderSummary1/>}></Route> */}
                <Route path="/vieworder" element={<ViewOrders />}></Route>
                <Route path="/updatestatus" element={<UpdateStatus />}></Route>
                {/* <Route path="/updatestatus" element={<UpdateStatus/>}></Route> */}
                <Route path="/vieworderitems" element={<OrderItems />}></Route>
                <Route path="/userorderhistory" element={<UserOrderHistory />}></Route>
                <Route path="/searchresults" element={<SearchProducts />}></Route>
                {/* all encryption on change password , userpages and adminpages ordersummary checkout etc*/}
                {/* slider(front home page and validation) */}
                <Route path="/searchoderid" element={<SearchOrderId />}></Route>
                <Route path="/contactus" element={<ContactUs />}></Route>
                {/* <Route path="/contactus" element={<ContactUs2 />}></Route> */}
                <Route path="/admincontactus" element={<AdminContactUs />}></Route>
                <Route path="/3rdAppApi1" element={<OthersAppApi1 />}></Route>
                <Route path="/3rdAppApi2" element={<OthersAppApi2 />}></Route>
                {/* <Route path="/3rdAppApi2" element={<OthersAppApi2b/>}></Route> */}
                <Route path="/3rdAppApi3" element={<OthersAppApi3 />}></Route>
                <Route path="/resetpassword" element={<ResetPassword />}></Route>
                <Route path="/extra" element={<Extra />}></Route>
                <Route path="/mycookie" element={<MyCookie />}></Route>
                <Route path="/mycookie2" element={<MyCookie2 />}></Route>
            </Routes>
        </>
    )
}
export default Siteroutes;