import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Cookies from "universal-cookie";
import { useDispatch } from "react-redux";
import { login } from "../reduxslices/authSlice";

function Login()
{
    const usercokkie = new Cookies()
    const [uname, setuname] = useState();
    const [pass, setpass] = useState();
    const [msg, setmsg] = useState();
    const [loading, setloading] = useState(false);
    const [terms, setterms] = useState(false);
    const dispatch = useDispatch()

    const navi = useNavigate();

    async function onlogin(e)
    {
        e.preventDefault()
        const logindata = { uname, pass, staySignedIn: terms };
        try
        {
            setloading(true)
            const resp = await axios.post(`${process.env.REACT_APP_APIURL}/api/login`, logindata, { withCredentials: true })
            // {withCredentials:true} is applied so that cookie can be formed

            if (resp.data.statuscode === 0)
            {
                toast.warn("Incorrect Username/Password")
            }
            else if (resp.data.statuscode === 1)
            {
                if (resp.data.userdata.actstatus === true)
                {
                    // setudata(resp.data.userdata)
                    dispatch(login(resp.data.userdata))
                    sessionStorage.setItem("userdata", JSON.stringify(resp.data.userdata));
                    if (terms)  // truthy value
                    {
                        usercokkie.set("staysignin", JSON.stringify(resp.data.userdata), { maxAge: 7 * 24 * 60 * 60, });
                    }

                    if (resp.data.userdata.usertype === "admin")
                    {
                        navi("/adminhome")
                    }
                    else
                    {
                        navi("/home")
                    }
                }
                else
                {
                    toast.error("Your account is not activated , please check your email and activate your account")
                }
            }
            else
            {
                toast.error("Some Problem Occured")
            }
        }
        catch (e)
        {
            toast.error("Error Occured " + e.message)
        }
        finally
        {
            setloading(false)
        }
    }

    useEffect(() =>
    {
        document.title = "Login";
    }, []);

    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Login Page</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    <h2>Login Form</h2>

                    <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
                        <form name="form1" onSubmit={onlogin}>
                            <input type="email" name="un" placeholder="Email Address(username)" required=" " onChange={(e) => setuname(e.target.value)} />
                            <input type="password" name="pass" placeholder="Password" required=" " onChange={(e) => setpass(e.target.value)} />
                            <div className="register-check-box">
                                <div className="check">
                                    <label className="checkbox">
                                        <input type="checkbox" name="cbx1" onChange={(e) => setterms(e.target.checked)} /><i> </i>Stay Sign In
                                    </label>
                                </div>
                            </div>
                            {
                                loading ?
                                    <div className="loader-container">
                                        <img src="images/loader.gif" alt="loader" className="loader" />
                                    </div> : <input type="submit" name="btn" value="Login" />
                            }
                            <Link to="/forgotpassword">Forgot Password</Link>
                            {msg}
                        </form>
                    </div>
                    <h4>For New People</h4>

                    <p><Link to="/signup">Register Here</Link> (Or) go back to <Link to="/">Home</Link><span className="glyphicon glyphicon-menu-right" aria-hidden="true"></span></p>
                </div>
            </div>

        </>
    )
}
export default Login;