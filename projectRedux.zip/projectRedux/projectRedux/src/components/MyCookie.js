import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import Cookies from 'universal-cookie'

function MyCookie()
{

  const cookiesobj = new Cookies(); // take care while fetching cookies , should be of uinversal package

  const [name, setname] = useState("")
  const [value, setvalue] = useState("")

  const savecookie = () =>
  {
    cookiesobj.set("usercookie", name, { maxAge: 604800 });  // maxAge in second
    if (cookiesobj.get("usercookie") !== undefined)
    {
      setvalue("Cookie Saved Succesfully")
    }
  }

  const readcookie = () =>
  {
    if (cookiesobj.get("usercookie") !== undefined)
    {
      setvalue(cookiesobj.get("usercookie"))
    }
  }

  const delcookie = () =>
  {
    if (cookiesobj.get("usercookie") !== undefined)
    {
      cookiesobj.remove("usercookie")
      setvalue("")
    }
  }


  return (
    <>
      <div className="breadcrumbs">
        <div className="container">
          <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
            <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
            <li className="active">Cookie Page</li>
          </ol>
        </div>
      </div>

      <div className="login">
        <div className="container">
          <h2> Cookies</h2>
          <input type="text" name="phone" className='form-control' placeholder='Name....' onChange={(e) => setname(e.target.value)} /><br />
          <button className='btn btn-primary' onClick={savecookie}>Set</button>&nbsp;
          <button className='btn btn-primary' onClick={readcookie}>Read</button>&nbsp;
          <button className='btn btn-danger' onClick={delcookie}>Delete</button><br /><br />
          {value}
        </div>
      </div><br /><br />
    </>
  )
}

export default MyCookie
