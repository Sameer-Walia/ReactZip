import Header from "./components/Header";
import Footer from "./components/Footer";
import Siteroutes from "./components/Siteroutes";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { createContext, useEffect, useState } from "react";
import AdminHeader from "./components/AdminHeader";
import Cookies from "universal-cookie";
import { login } from "./reduxslices/authSlice";
import { useDispatch, useSelector } from "react-redux";


function App()
{
  const usercokkie = new Cookies()
  const { isLoggedIn, usertype } = useSelector((state) => state.auth)
  const dispatch = useDispatch()

  useEffect(() =>
  {
    if (sessionStorage.getItem("userdata") !== null)
    {
      // setudata(JSON.parse(sessionStorage.getItem("userdata")));
      dispatch(login(JSON.parse(sessionStorage.getItem("userdata"))))
    }
  }, [])

  useEffect(() =>
  {
    const cookieUser = usercokkie.get("staysignin"); // universal-cookie auto-parses JSON , no need to do JSON.parse
    if (cookieUser)
    {
      // setudata(cookieUser);
      dispatch(login(cookieUser))
      sessionStorage.setItem("userdata", JSON.stringify(cookieUser));
    }
  }, []);


  return (
    <>

      {
        isLoggedIn === false ? <Header />
          : usertype === "admin" ? <AdminHeader /> :
            <Header />
      }
      <Siteroutes />
      <Footer />
      <ToastContainer theme="colored" />
    </>
  );
}
export default App;