const express = require('express')
const router = express.Router();

const {verifyjsontoken , verifyadmin} = require('../utils/auth')
const upload = require('../utils/multerConfig')

const finalorderControllers  = require("../controllers/finalorderControllers");

router.post("/saveorder" , finalorderControllers.saveorder)
router.get("/getorderid" , finalorderControllers.getorderid)
router.get("/getallordersbydate" ,verifyjsontoken , verifyadmin , finalorderControllers.getallordersbydate)
router.delete("/delorder/:id" ,verifyjsontoken , verifyadmin , finalorderControllers.delorder)
router.put("/updatestatus" , finalorderControllers.updatestatus)
router.get("/getorderproducts" , finalorderControllers.getorderproducts)
router.get("/getuserorders" , verifyjsontoken , finalorderControllers.getuserorders)
router.get("/SearchOrderId" , finalorderControllers.SearchOrderId)

module.exports = router;
