const CartModel = require('../models/cartModel')

exports.addtocart = async (req, res) => 
{
  try
  {
    const newrecord = new CartModel({ pid:req.body.pid ,Picture: req.body.picture, ProdName: req.body.pname, Rate: req.body.rate, Qty: req.body.qty, TotalCost: req.body.tc, Username: req.body.username })

    const result = await newrecord.save();

    if (result) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}


exports.getcart = async (req, res) => 
{
  try 
  {
    const result = await CartModel.find({ Username: req.query.un })
    if (result.length === 0)
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, cartinfo: result })
    }
  }
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.delproduct = async (req, res) => 
{
  try
  {
    const result = await CartModel.deleteOne({ _id: req.params.id })
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.deletecart = async(req,res)=>
{
  try
  {
    const result = await CartModel.deleteMany({Username:req.query.un})//{ acknowledged: true, deletedCount: ... }
    if(result.deletedCount>=1)
    {
      res.send({statuscode:1})
    }
    else
    {
      res.send({statuscode:0})
    }    
  }
  catch (e) 
  {
    res.send({statuscode:-1})
    console.log(e.message)
  } 
}