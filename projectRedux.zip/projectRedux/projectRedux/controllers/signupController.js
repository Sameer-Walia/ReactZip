const SignupModel = require("../models/signupModel");
const { v4: uuidv4 } = require('uuid')  // to set unique id after signup where gmail link is open before login
const bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
const { sendMail } = require('../utils/mailer')


exports.signup = async (req, res) => 
{
  try
  {
    const acttoken = uuidv4();
    console.log(acttoken)

    const encryp_pass = bcrypt.hashSync(req.body.pass, 10)

    const newrecord = new SignupModel({ pname: req.body.name, phone: req.body.phone, username: req.body.uname, password: encryp_pass, usertype: "normal", actstatus: false, token: acttoken })

    const result = await newrecord.save();

    if (result) 
    {
      const mailOptions = {
        from: 'class@gtbinstitute.com', // transporter username email
        to: req.body.uname,             // user's email id
        subject: 'Activation Mail from SuperMarket.com',
        html: `Dear ${req.body.name}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3000/activateaccount?code=${acttoken}'>Activate Account<a/>`
      };

      const mailresp = await sendMail(mailOptions);
      if (mailresp.success === true)
      {
        res.send({ statuscode: 1 })
      }
      else
      {
        res.send({ statuscode: 2 })
      }

    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch (e) 
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
}



exports.resendmail = async (req, res) =>
{
  try 
  {
    const { uname } = req.body;

    const user = await SignupModel.findOne({ username: uname });
    console.log(user)
    if (user === null) 
    {
      res.send({ statuscode: 0, msg: "User not found with given email" });
    }
    else
    {

      const updateresult = await SignupModel.updateOne({ username: uname }, { $set: { actstatus: false } });
      if (updateresult.modifiedCount === 1)
      {
        const mailOptions = {
          from: 'class@gtbinstitute.com',
          to: uname,
          subject: 'Activation Mail from SuperMarket.com',
          html: `Dear ${user.pname}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3000/activateaccount?code=${user.token}'>Activate Account<a/>`
        };

        const mailresp = await sendMail(mailOptions);
        if (mailresp.success === true)
        {
          res.send({ statuscode: 1 })
        }
        else
        {
          res.send({ statuscode: 2 })
        }
      }
      else
      {
        const mailOptions = {
          from: 'class@gtbinstitute.com',
          to: uname,
          subject: 'Activation Mail from SuperMarket.com',
          html: `Dear ${user.pname}<br/><br/>Thanks for signing up on our website.<br/><br/>Click on the following link to activate your account.<br/><br/><a href='http://localhost:3000/activateaccount?code=${user.token}'>Activate Account<a/>`
        };

        const mailresp = await sendMail(mailOptions);
        if (mailresp.success === true)
        {
          res.send({ statuscode: 1 })
        }
        else
        {
          res.send({ statuscode: 2 })
        }
      }
    }
  }
  catch (e) 
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
};

exports.activateuseraccount = async (req, res) =>
{
  try
  {
    const updateresult = await SignupModel.updateOne({ token: req.body.code }, { $set: { actstatus: true } });
    if (updateresult.modifiedCount === 1)
    {
      res.send({ statuscode: 1 })
    }
    else
    {
      res.send({ statuscode: 0 })
    }
  }
  catch (e)
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
}


exports.login = async (req, res) => 
{
  try 
  {
    const result = await SignupModel.findOne({ username: req.body.uname }).select("-phone");
    // .select("-phone"); = so phone:result.phone cannot be store in respdata

    console.log(result)
    if (result === null)
    {
      res.send({ statuscode: 0 })
    }
    else
    {
      if (bcrypt.compareSync(req.body.pass, result.password))
      {

        const jsontoken = jwt.sign({ id: result._id, role: result.usertype }, process.env.JWT_SKEY, { expiresIn: "15m" })
        const refreshjsontoken = jwt.sign({ id: result._id, role: result.usertype }, process.env.JWT_REFRESH_SKEY, { expiresIn: "7d" })

        const respdata = { _id: result._id, pname: result.pname, phone: result.phone, username: result.username, usertype: result.usertype, actstatus: result.actstatus }

        res.cookie("authToken", jsontoken, {
          httpOnly: true,
          secure: false,
          sameSite: "lax",
          maxAge: 15 * 60 * 1000,  // 15 min
        });

        res.cookie("refreshToken", refreshjsontoken, {
          httpOnly: true,
          secure: false,
          sameSite: "lax",
          maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
        });

        res.send({ statuscode: 1, userdata: respdata })

      }
      else
      {
        res.send({ statuscode: 0 })
      }
    }
  }
  catch (e) 
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
};

exports.logout = (req, res) => 
{
  try 
  {
    res.clearCookie("authToken");
    res.clearCookie("refreshToken");
    res.clearCookie("staysignin");
    res.send({ statuscode: 1 })
  }
  catch (e) 
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
};


exports.searchuser = async (req, res) => 
{
  try
  {
    const result = await SignupModel.findOne({ username: req.query.un });
    console.log(result)
    if (result) 
    {
      res.send({ statuscode: 1, searchdata: result })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch (e)
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
}

exports.getallusers = async (req, res) => 
{
  try
  {
    const result = await SignupModel.find();
    // console.log(result)
    if (result.length === 0) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, usersdata: result })
    }
  }
  catch (e)
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
}

exports.fetchoneuser = async (req, res) => 
{
  try
  {
    const result = await SignupModel.findOne({ _id: req.params.id });
    // console.log(result)
    if (result === null) 
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1, oneuserdata: result })
    }
  }
  catch (e)
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
}

exports.updateoneuser = async (req, res) => 
{
  try
  {
    const update = await SignupModel.updateOne({ _id: req.body.userid }, { $set: { pname: req.body.name, phone: req.body.phone, username: req.body.uname } })

    if (update.modifiedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch (e)
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
}

exports.deluser = async (req, res) => 
{
  try
  {
    const result = await SignupModel.deleteOne({ _id: req.params.uid })  //{acknowledge:true , deletdCount:1 }
    // console.log(result)
    if (result.deletedCount === 1) 
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch (e)
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
}

exports.changepassword = async (req, res) => 
{
  try
  {
    const result = await SignupModel.findOne({ username: req.body.uname })
    console.log(result)
    if (result === null)
    {
      res.send({ statuscode: 0 })
    }
    else
    {
      if (bcrypt.compareSync(req.body.currpass, result.password))
      {
        const encryp_newpass = bcrypt.hashSync(req.body.newpass, 10)
        const updatepass = await SignupModel.updateOne({ username: req.body.uname }, { $set: { password: encryp_newpass } })
        if (updatepass.modifiedCount === 1) 
        {
          res.clearCookie("authToken");
          res.clearCookie("refreshToken");
          res.clearCookie("staysignin");
          res.send({ statuscode: 1 })
        }
        else 
        {
          res.send({ statuscode: 0 })
        }
      }
      else
      {
        res.send({ statuscode: 0 })
      }
    }
  }
  catch (e)
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
}


// contact-us api  , here it has no model , message directly sent on email

exports.ContactUs = async (req, res) =>
{
  try
  {
    // verify capctha
    const secretKey = "6LfERsgrAAAAAOCiGEhPE5XOgemCKahJfqdWUw5v"; // backend only
    const captchaURL = `https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${req.body.captchaToken}`;

    const captchaResponse = await fetch(captchaURL, { method: "POST" });
    const captchaData = await captchaResponse.json();
    console.log(captchaData)
    if (captchaData.success === false) 
    {
      return res.json({ success: 0, msg: "Captcha verification failed" });
    }

    //  If captcha passes → send email

    const mailOptions = {
      from: 'class@gtbinstitute.com', // transporter username email
      to: 'sameerwalia13@gmail.com',  // any email id of admin where u want to send email
      replyTo: req.body.email,
      subject: 'Message from website - Contact Us Page',
      html: `<b>Name:- </b>${req.body.uname}<br/><b>Phone:- </b>${req.body.phone}<br/><b>Email:- </b>${req.body.email}<br/><b>Message:- </b>${req.body.message}`
    };

    const mailresp = await sendMail(mailOptions);
    if (mailresp.success === true)
    {
      res.send({ statuscode: 1 })
    }
    else
    {
      res.send({ statuscode: 0 })
    }

  }
  catch (e)
  {
    res.send({ statuscode: -1 })
    console.log(e.message)
  }
}